
import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// AI 辅助分析简历
export const analyzeResume = async (resumeText: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `请作为资深 HR 分析以下简历，并与“高级开发工程师”职位匹配。返回 JSON：score (0-100), topSkills (array), pros (string), cons (string)。简历：${resumeText}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          topSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
          pros: { type: Type.STRING },
          cons: { type: Type.STRING }
        }
      }
    }
  });
  const text = response.text || '{}';
  return JSON.parse(text.trim());
};

// AI 辅助生成招聘 JD
export const generateJobDescription = async (title: string, dept: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `请为 ${dept} 部门的 ${title} 职位生成一份专业的中文招聘启事，包含职位描述、任职要求和加分项。`,
  });
  return response.text;
};

// AI 生成绩效建议
export const generatePerformanceFeedback = async (metrics: any) => {
  const ai = getAI();
  const metricsStr = typeof metrics === 'string' ? metrics : JSON.stringify(metrics);
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `基于以下员工表现数据给出三条具体的中文改进建议：${metricsStr}`,
  });
  return response.text;
};

// AI 仪表盘指标深度诊断
export const analyzeDashboardMetric = async (metricName: string, value: any, context: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `你是一个人力资源专家。请针对以下数据指标进行简短精炼的诊断（30字以内）：指标名称为“${metricName}”，当前数值为“${value}”，上下文背景：“${context}”。`,
  });
  return response.text;
};

// AI 趋势洞察预测
export const analyzeDashboardTrend = async (chartName: string, data: any[]) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `作为人力资源顾问，分析这份“${chartName}”的数据走势：${JSON.stringify(data)}。请给出两个核心洞察点（100字以内），涵盖增长动能或组织隐忧。`,
    config: {
      thinkingConfig: { thinkingBudget: 4000 }
    }
  });
  return response.text;
};

// AI 薪资核算审计
export const auditPayrollData = async (data: any[]) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `请审计以下薪资核算数据，识别潜在异常（如某人薪资过高/过低、计算逻辑不一致等），并给出 3 条建议。数据：${JSON.stringify(data.slice(0, 10))}`,
  });
  return response.text;
};
