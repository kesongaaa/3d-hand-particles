import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Search, UserPlus, MoreVertical, Mail, Phone, X, Calendar, 
  Hash, BadgeCheck, UserCog, CreditCard, GraduationCap, 
  ShieldCheck, Heart, Filter, Columns, ChevronDown, 
  ListFilter, AlertCircle, CheckCircle2, UserMinus, Clock3, Download, Edit3, FileUp, Upload,
  Briefcase, Landmark, BookOpen, MapPin, Scale, ChevronUp, Command, GripVertical,
  Users as UsersIcon, UserCheck, UserX, UserPlus2, ChevronLeft, ChevronRight, Sparkles, Loader2, Trash2, Clock
} from 'lucide-react';
import { Employee, EmployeeType, UserRole, Gender, EmployeeStatus, FieldSetting, Department, Position } from '../types';
import { getInitials } from '../utils/pinyinUtils';
import { AIDialog } from './Dashboard';
import { analyzeDashboardTrend } from '../services/geminiService';
import * as XLSX from 'xlsx';

interface Props {
  employees: Employee[];
  onAddEmployee: (emp: Partial<Employee>) => void;
  onUpdateEmployee: (emp: Partial<Employee>) => void;
  onDeleteEmployee: (id: string) => void;
  onBulkAddEmployees: (emps: Employee[]) => void;
  fieldSettings: FieldSetting[];
  onUpdateFieldSettings: (settings: FieldSetting[]) => void;
  departments: Department[];
  positions: Position[];
}

const COLUMN_CONFIG_BASE = [
  { key: 'name', label: '姓名', fixed: true },
  { key: 'employeeId', label: '工号', fixed: true },
  { key: 'department', label: '部门' },
  { key: 'position', label: '职位' },
  { key: 'status', label: '状态' },
  { key: 'type', label: '类型' },
  { key: 'seniority', label: '司龄' },
  { key: 'phone', label: '手机号' },
  { key: 'idCard', label: '身份证号' },
  { key: 'ethnicity', label: '民族' },
  { key: 'politicalStatus', label: '政治面貌' },
  { key: 'joinDate', label: '入职日期' },
  { key: 'permanentDate', label: '转正日期' },
  { key: 'education', label: '学历' },
  { key: 'bankCard', label: '银行卡号' },
  { key: 'contractEndDate', label: '合同到期' }
];

type FilterTab = '全部' | '在职' | '正式' | '实习' | '试用期' | '待离职' | '已离职';

const EmployeeList: React.FC<Props> = ({ employees, onAddEmployee, onUpdateEmployee, onDeleteEmployee, onBulkAddEmployees, fieldSettings, onUpdateFieldSettings, departments, positions }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmpId, setEditingEmpId] = useState<string | null>(null);
  const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<FilterTab>('全部');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiInsight, setAiInsight] = useState<{ title: string; content: string } | null>(null);
  
  // 分页状态
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [jumpPage, setJumpPage] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const columnPickerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const tableContainerRef = useRef<HTMLDivElement>(null);
  
  const dragItemIndex = useRef<number | null>(null);
  const dragOverItemIndex = useRef<number | null>(null);
  const scrollInterval = useRef<number | null>(null);
  
  const [filters, setFilters] = useState({
    department: '全部',
    status: '全部',
    type: '全部'
  });

  const [visibleColumns, setVisibleColumns] = useState<string[]>([
    'name', 'employeeId', 'department', 'position', 'status', 'type', 'seniority'
  ]);

  const [newEmp, setNewEmp] = useState<Partial<Employee>>({
    name: '', email: '', gender: '男', ethnicity: '汉族', idCard: '', 
    phone: '', address: '', department: departments[0]?.name || '', position: positions[0]?.name || '', type: '正式',
    joinDate: new Date().toISOString().split('T')[0], politicalStatus: '群众',
    education: '本科', degree: '学士', graduationDate: '', bankCard: '', 
    contractType: '劳动合同', contractStartDate: new Date().toISOString().split('T')[0], 
    contractEndDate: '', status: '在职', probationDuration: 3, permanentDate: ''
  });

  // 数据汇总统计
  const stats = useMemo(() => {
    return {
      total: employees.length,
      active: employees.filter(e => e.status === '在职').length,
      fulltime: employees.filter(e => e.status === '在职' && e.type === '正式').length,
      intern: employees.filter(e => e.status === '在职' && e.type === '实习').length,
      probation: employees.filter(e => e.status === '在职' && e.type === '试用期').length,
      pending: employees.filter(e => e.status === '在职' && e.contractEndDate && new Date(e.contractEndDate).getTime() < new Date().getTime() + 2592000000).length,
      resigned: employees.filter(e => e.status === '离职').length,
    };
  }, [employees]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (columnPickerRef.current && !columnPickerRef.current.contains(event.target as Node)) {
        setIsColumnPickerOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      stopScrolling();
    };
  }, []);

  const sortedColumnConfig = useMemo(() => {
    const orderMap = new Map(fieldSettings.map(f => [f.key, f.order]));
    return [...COLUMN_CONFIG_BASE].sort((a, b) => {
      const orderA = orderMap.get(a.key) ?? 999;
      const orderB = orderMap.get(b.key) ?? 999;
      return orderA - orderB;
    });
  }, [fieldSettings]);

  const calculatePermanentDate = (joinDate: string, duration: number) => {
    if (!joinDate) return '';
    const date = new Date(joinDate);
    // Explicitly use numeric values for arithmetic
    const currentMonth = Number(date.getMonth());
    date.setMonth(currentMonth + Number(duration));
    return date.toISOString().split('T')[0];
  };

  const calculateSeniority = (joinDate: string) => {
    if (!joinDate) return '-';
    const start = new Date(joinDate);
    const end = new Date();
    // Fix: Ensure both sides of the arithmetic operation are treated as numbers to avoid TS errors
    let years = Number(end.getFullYear()) - Number(start.getFullYear());
    let months = Number(end.getMonth()) - Number(start.getMonth());
    if (months < 0) { years--; months += 12; }
    if (years === 0 && months === 0) return '首月';
    return `${years > 0 ? years + '年' : ''}${months > 0 ? months + '个月' : ''}`;
  };

  // 1. 过滤逻辑
  const filteredEmployees = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    const result = employees.filter(emp => {
      if (activeTab === '在职' && emp.status !== '在职') return false;
      if (activeTab === '正式' && (emp.status !== '在职' || emp.type !== '正式')) return false;
      if (activeTab === '实习' && (emp.status !== '在职' || emp.type !== '实习')) return false;
      if (activeTab === '试用期' && (emp.status !== '在职' || emp.type !== '试用期')) return false;
      if (activeTab === '已离职' && emp.status !== '离职') return false;
      if (activeTab === '待离职') {
         if (emp.status !== '在职' || !emp.contractEndDate) return false;
         // Fix: Use new Date().getTime() instead of Date.now() to ensure numeric arithmetic on line 122
         const isExpiring = new Date(emp.contractEndDate).getTime() < (new Date().getTime() + 2592000000);
         if (!isExpiring) return false;
      }

      const initials = getInitials(emp.name);
      const searchStr = `${emp.name} ${emp.employeeId || ''} ${initials}`.toLowerCase();
      const matchesSearch = term === '' || searchStr.includes(term);
      const matchesDept = filters.department === '全部' || emp.department === filters.department;
      
      return matchesSearch && matchesDept;
    });
    return result;
  }, [employees, searchTerm, activeTab, filters]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, activeTab, filters]);

  // 2. 分页切片逻辑
  const totalPages = Math.ceil(filteredEmployees.length / pageSize);
  const paginatedEmployees = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredEmployees.slice(start, start + pageSize);
  }, [filteredEmployees, currentPage, pageSize]);

  const handlePageChange = (p: number) => {
    if (p >= 1 && p <= totalPages) {
      setCurrentPage(p);
      tableContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleAiAnalyzeList = async () => {
    if (isAiLoading) return;
    setIsAiLoading(true);
    try {
      const dataForAi = filteredEmployees.slice(0, 10).map(e => ({ name: e.name, dept: e.department, pos: e.position, type: e.type, edu: e.education }));
      const insight = await analyzeDashboardTrend(`员工群体 (${activeTab})`, dataForAi);
      setAiInsight({ title: `员工画像分析 - ${activeTab}`, content: insight });
    } catch (err) {
      alert('AI 分析失败，请稍后重试');
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleRowClick = (emp: Employee) => {
    setEditingEmpId(emp.id);
    setNewEmp({ ...emp });
    setIsModalOpen(true);
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    onDeleteEmployee(id);
  };

  const handleAddNew = () => {
    setEditingEmpId(null);
    const today = new Date().toISOString().split('T')[0];
    setNewEmp({
      name: '', email: '', gender: '男', ethnicity: '汉族', idCard: '', 
      phone: '', address: '', department: departments[0]?.name || '', position: positions[0]?.name || '', type: '正式',
      joinDate: today, politicalStatus: '群众', education: '本科', degree: '学士', 
      graduationDate: '', bankCard: '', contractType: '劳动合同',
      contractStartDate: today, contractEndDate: '', status: '在职',
      probationDuration: 3, permanentDate: calculatePermanentDate(today, 3)
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEmpId) {
      onUpdateEmployee(newEmp);
    } else {
      onAddEmployee(newEmp);
    }
    setIsModalOpen(false);
  };

  const isRequired = (key: string) => fieldSettings.find(f => f.key === key)?.required || false;

  const toggleColumn = (key: string) => {
    setVisibleColumns(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]);
  };

  const startScrolling = (direction: 'up' | 'down') => {
    if (scrollInterval.current) return;
    scrollInterval.current = window.setInterval(() => {
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTop += (direction === 'up' ? -8 : 8);
      }
    }, 16);
  };

  const stopScrolling = () => {
    if (scrollInterval.current) {
      clearInterval(scrollInterval.current);
      scrollInterval.current = null;
    }
  };

  const handleDragOverContainer = (e: React.DragEvent) => {
    e.preventDefault();
    if (!scrollContainerRef.current) return;
    const rect = scrollContainerRef.current.getBoundingClientRect();
    const threshold = 50;
    if (e.clientY < rect.top + threshold) {
      startScrolling('up');
    } else if (e.clientY > rect.bottom - threshold) {
      startScrolling('down');
    } else {
      stopScrolling();
    }
  };

  const handleSort = () => {
    stopScrolling();
    if (dragItemIndex.current === null || dragOverItemIndex.current === null) return;
    const newList = [...sortedColumnConfig];
    const draggedItem = newList.splice(dragItemIndex.current, 1)[0];
    newList.splice(dragOverItemIndex.current, 0, draggedItem);
    const updatedSettings = [...fieldSettings];
    newList.forEach((item, index) => {
      const settingIndex = updatedSettings.findIndex(s => s.key === item.key);
      if (settingIndex !== -1) {
        updatedSettings[settingIndex] = { ...updatedSettings[settingIndex], order: index };
      } else {
        updatedSettings.push({ key: item.key, label: item.label, required: false, order: index });
      }
    });
    onUpdateFieldSettings(updatedSettings);
    dragItemIndex.current = null;
    dragOverItemIndex.current = null;
  };

  return (
    <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 shrink-0">
        {[
          { id: '全部', label: '全部员工', count: stats.total, icon: <UsersIcon size={16}/> },
          { id: '在职', label: '在职员工', count: stats.active, icon: <UserCheck size={16}/> },
          { id: '正式', label: '正式员工', count: stats.fulltime, icon: <BadgeCheck size={16}/> },
          { id: '试用期', label: '试用期', count: stats.probation, icon: <Clock3 size={16}/> },
          { id: '实习', label: '实习员工', count: stats.intern, icon: <GraduationCap size={16}/> },
          { id: '待离职', label: '待离职', count: stats.pending, icon: <UserMinus size={16}/> },
          { id: '已离职', label: '已离职', count: stats.resigned, icon: <UserX size={16}/> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as FilterTab)}
            className={`flex flex-col items-start p-4 rounded-2xl border transition-all text-left group ${
              activeTab === tab.id 
                ? 'bg-indigo-600 border-indigo-600 shadow-lg shadow-indigo-100' 
                : 'bg-white border-slate-100 hover:border-indigo-200 shadow-sm'
            }`}
          >
            <div className={`p-2 rounded-lg mb-2 transition-colors ${activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-slate-50 text-slate-400 group-hover:text-indigo-600 group-hover:bg-indigo-50'}`}>
              {tab.icon}
            </div>
            <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${activeTab === tab.id ? 'text-indigo-100' : 'text-slate-400'}`}>{tab.label}</p>
            <p className={`text-xl font-black ${activeTab === tab.id ? 'text-white' : 'text-slate-900'}`}>{tab.count}</p>
          </button>
        ))}
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4 shrink-0">
        <div className="flex items-center gap-3 flex-1 w-full md:w-auto">
          <div className="relative group w-full md:w-96">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">
              <Search size={18} />
            </div>
            <input 
              type="text"
              placeholder={`在 ${activeTab} 中搜索姓名 / 工号 / 拼音`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all shadow-sm"
            />
          </div>
          <button 
            onClick={handleAiAnalyzeList}
            disabled={isAiLoading}
            className="flex items-center gap-2 bg-slate-900 text-white px-5 py-2.5 rounded-2xl text-sm font-bold shadow-lg hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-50"
          >
            {isAiLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} className="text-amber-400" />}
            <span className="hidden lg:inline">AI 员工画像分析</span>
          </button>
        </div>
        
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2.5 rounded-2xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
            <Upload size={16} /> <span className="hidden sm:inline">批量导入</span>
            <input type="file" ref={fileInputRef} className="hidden" />
          </button>
          
          <div className="relative" ref={columnPickerRef}>
            <button 
              onClick={() => setIsColumnPickerOpen(!isColumnPickerOpen)} 
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold transition-all shadow-sm border ${isColumnPickerOpen ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
            >
              <Columns size={16} /> <span className="hidden sm:inline">字段配置</span>
            </button>
            {isColumnPickerOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 p-4 animate-in zoom-in-95 duration-200">
                <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-100">
                   <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">显示与排序</h4>
                   <button onClick={() => setIsColumnPickerOpen(false)} className="text-slate-300 hover:text-slate-500 transition-colors"><X size={14}/></button>
                </div>
                <div 
                  ref={scrollContainerRef}
                  onDragOver={handleDragOverContainer}
                  className="space-y-1 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar scroll-smooth"
                >
                  {sortedColumnConfig.map((col, index) => (
                    <div 
                      key={col.key}
                      draggable
                      onDragStart={() => (dragItemIndex.current = index)}
                      onDragEnter={() => (dragOverItemIndex.current = index)}
                      onDragEnd={handleSort}
                      onDragOver={(e) => e.preventDefault()}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-move group transition-all active:scale-[0.98] active:bg-indigo-50"
                    >
                      <GripVertical size={14} className="text-slate-300 group-hover:text-slate-400 shrink-0" />
                      <label className="flex items-center gap-3 flex-1 cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={visibleColumns.includes(col.key)} 
                          onChange={() => toggleColumn(col.key)} 
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" 
                        />
                        <span className="text-sm text-slate-600 group-hover:text-indigo-600 transition-colors truncate">{col.label}</span>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button onClick={handleAddNew} className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-sm font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">
            <UserPlus size={16} /> <span className="hidden sm:inline">入职办理</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm flex flex-col flex-1 overflow-hidden">
        <div 
          ref={tableContainerRef}
          className="flex-1 overflow-y-auto overflow-x-auto custom-scrollbar-horizontal custom-scrollbar"
        >
          <table className="w-full text-left border-collapse min-w-max table-fixed">
            <thead className="sticky top-0 z-30 bg-white">
              <tr className="bg-slate-50/80 backdrop-blur-sm">
                {sortedColumnConfig.filter(c => visibleColumns.includes(c.key)).map(col => (
                  <th key={col.key} className={`px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 whitespace-nowrap w-[150px] ${col.fixed ? 'sticky left-0 bg-slate-50 z-40 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]' : ''}`}>
                    {col.label}
                  </th>
                ))}
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 text-right whitespace-nowrap w-[120px]">管理</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {paginatedEmployees.length > 0 ? (
                paginatedEmployees.map(emp => (
                  <tr key={emp.id} onClick={() => handleRowClick(emp)} className="hover:bg-indigo-50/30 transition-all cursor-pointer group">
                    {sortedColumnConfig.filter(c => visibleColumns.includes(c.key)).map(col => {
                      if (col.key === 'name') {
                        return (
                          <td key={col.key} className="px-6 py-4 sticky left-0 bg-white group-hover:bg-indigo-50/10 transition-all z-10 whitespace-nowrap shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] overflow-hidden text-ellipsis">
                            <div className="flex items-center gap-3">
                              <img src={emp.avatar} className="w-8 h-8 rounded-lg object-cover ring-2 ring-slate-100 shadow-sm shrink-0" />
                              <span className="text-sm font-bold text-slate-900 truncate">{emp.name}</span>
                            </div>
                          </td>
                        );
                      }
                      if (col.key === 'status') {
                         return (
                          <td key={col.key} className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${emp.status === '在职' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'}`}>
                              {emp.status}
                            </span>
                          </td>
                        );
                      }
                      if (col.key === 'seniority') {
                         return <td key={col.key} className="px-6 py-4 text-xs font-bold text-indigo-600 whitespace-nowrap">{calculateSeniority(emp.joinDate)}</td>;
                      }
                      if (col.key === 'type') {
                         return (
                          <td key={col.key} className="px-6 py-4 whitespace-nowrap">
                            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">{emp.type}</span>
                          </td>
                        );
                      }
                      return (
                        <td key={col.key} className="px-6 py-4 text-sm text-slate-600 whitespace-nowrap overflow-hidden text-ellipsis">
                          {(emp as any)[col.key] || '-'}
                        </td>
                      );
                    })}
                    <td className="px-6 py-4 text-right whitespace-nowrap">
                      <div className="flex justify-end items-center gap-3">
                        <button className="p-1.5 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"><Edit3 size={16} /></button>
                        <button onClick={(e) => handleDelete(e, emp.id)} className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"><Trash2 size={16} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={visibleColumns.length + 1} className="px-6 py-20 text-center text-slate-400">
                    <div className="flex flex-col items-center gap-2">
                      <Search size={40} className="opacity-20" />
                      <p className="text-sm">未找到{activeTab}相关员工</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl my-8 animate-in zoom-in-95 duration-300">
            <div className="px-10 py-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50 sticky top-0 rounded-t-[2.5rem] z-10">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{editingEmpId ? '维护档案信息' : '办理正式入职'}</h3>
                <p className="text-xs text-slate-500 mt-1">当前司龄：<span className="text-indigo-600 font-bold">{calculateSeniority(newEmp.joinDate || '')}</span></p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-slate-600 bg-white rounded-full border border-slate-100 transition-all hover:rotate-90">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-10 space-y-12 max-h-[75vh] overflow-y-auto custom-scrollbar">
              <section>
                <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                  <BadgeCheck className="text-indigo-600" size={20} />
                  <h4 className="font-bold text-slate-800">1. 基本身份信息</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-x-6 gap-y-8">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">姓名 {isRequired('name') && '*'}</label>
                    <input required={isRequired('name')} value={newEmp.name} onChange={e => setNewEmp({...newEmp, name: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-indigo-500 outline-none transition-all" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">性别</label>
                    <select value={newEmp.gender} onChange={e => setNewEmp({...newEmp, gender: e.target.value as Gender})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all">
                      <option>男</option><option>女</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">手机号 {isRequired('phone') && '*'}</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14}/>
                      <input required={isRequired('phone')} value={newEmp.phone} onChange={e => setNewEmp({...newEmp, phone: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">身份证号 {isRequired('idCard') && '*'}</label>
                    <input required={isRequired('idCard')} value={newEmp.idCard} onChange={e => setNewEmp({...newEmp, idCard: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all" />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><Calendar size={10}/> 入职日期</label>
                    <input 
                      type="date" 
                      value={newEmp.joinDate} 
                      onChange={e => {
                        const newJoinDate = e.target.value;
                        setNewEmp({
                          ...newEmp, 
                          joinDate: newJoinDate, 
                          permanentDate: calculatePermanentDate(newJoinDate, newEmp.probationDuration || 0)
                        });
                      }} 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><Clock size={10}/> 试用期时长 (月)</label>
                    <input 
                      type="number" 
                      min="0"
                      max="12"
                      value={newEmp.probationDuration} 
                      onChange={e => {
                        const duration = parseInt(e.target.value) || 0;
                        setNewEmp({
                          ...newEmp, 
                          probationDuration: duration,
                          permanentDate: calculatePermanentDate(newEmp.joinDate || '', duration)
                        });
                      }} 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><BadgeCheck size={10}/> 转正时间</label>
                    <div className="relative">
                      <input 
                        type="date" 
                        value={newEmp.permanentDate} 
                        onChange={e => setNewEmp({...newEmp, permanentDate: e.target.value})} 
                        className="w-full bg-indigo-50/50 border border-indigo-100 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-indigo-700" 
                      />
                      <div className="absolute -right-2 -top-2 bg-indigo-600 text-white text-[8px] px-1.5 py-0.5 rounded-full shadow-sm">AI 推算</div>
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                  <Briefcase className="text-amber-600" size={20} />
                  <h4 className="font-bold text-slate-800">2. 岗位与状态</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">所属部门</label>
                    <select 
                      value={newEmp.department} 
                      onChange={e => setNewEmp({...newEmp, department: e.target.value})} 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      {departments.sort((a,b) => a.order - b.order).map(d => (
                        <option key={d.id} value={d.name}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">标准职位</label>
                    <select 
                      value={newEmp.position} 
                      onChange={e => setNewEmp({...newEmp, position: e.target.value})} 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      {positions.map(p => (
                        <option key={p.id} value={p.name}>{p.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">员工类型</label>
                    <select value={newEmp.type} onChange={e => setNewEmp({...newEmp, type: e.target.value as EmployeeType})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none">
                      <option>正式</option><option>试用期</option><option>实习</option><option>外包</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">在职状态</label>
                    <select value={newEmp.status} onChange={e => setNewEmp({...newEmp, status: e.target.value as EmployeeStatus})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none font-bold text-indigo-600">
                      <option>在职</option><option>离职</option>
                    </select>
                  </div>
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                  <BookOpen className="text-emerald-600" size={20} />
                  <h4 className="font-bold text-slate-800">3. 学历信息</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">学历 {isRequired('education') && '*'}</label>
                    <select value={newEmp.education} onChange={e => setNewEmp({...newEmp, education: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500">
                      <option>博士</option><option>硕士</option><option>本科</option><option>大专</option><option>中专</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">学位</label>
                    <input value={newEmp.degree} onChange={e => setNewEmp({...newEmp, degree: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none" placeholder="如：工学学士" />
                  </div>
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-6 pb-2 border-b border-slate-100">
                  <CreditCard className="text-indigo-600" size={20} />
                  <h4 className="font-bold text-slate-800">4. 财务信息</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">银行卡号 {isRequired('bankCard') && '*'}</label>
                    <div className="relative">
                       <Landmark className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14}/>
                       <input required={isRequired('bankCard')} value={newEmp.bankCard} onChange={e => setNewEmp({...newEmp, bankCard: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2.5 outline-none font-mono focus:ring-2 focus:ring-indigo-500" placeholder="工资发放卡号" />
                    </div>
                  </div>
                </div>
              </section>

              <div className="pt-8 flex gap-4 sticky bottom-0 bg-white py-4 border-t border-slate-50">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-slate-100 rounded-2xl font-bold text-slate-600 hover:bg-slate-200 transition-all">取消修改</button>
                <button type="submit" className="flex-[2] py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                  <Heart size={18} /> 确认保存并归档
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {aiInsight && (
        <AIDialog 
          title={aiInsight.title} 
          content={aiInsight.content} 
          onClose={() => setAiInsight(null)} 
        />
      )}
    </div>
  );
};

export default EmployeeList;