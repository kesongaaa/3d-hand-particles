
import React, { useState } from 'react';
import { JobPost } from '../types';
import { Plus, Bot, Sparkles, MapPin, Briefcase, FileText, ChevronRight } from 'lucide-react';
import { generateJobDescription } from '../services/geminiService';

interface Props {
  jobs: JobPost[];
  onAddJob: (job: JobPost) => void;
}

const Recruitment: React.FC<Props> = ({ jobs, onAddJob }) => {
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [newJob, setNewJob] = useState({ title: '', dept: '技术部', location: '杭州' });
  const [aiResult, setAiResult] = useState('');

  const handleAiJD = async () => {
    if (!newJob.title) return alert('请输入职位名称');
    setIsAiLoading(true);
    try {
      const jd = await generateJobDescription(newJob.title, newJob.dept);
      setAiResult(jd);
      setShowEditor(true);
    } catch (e) {
      alert('AI 服务不可用');
    } finally {
      setIsAiLoading(false);
    }
  };

  const publishJob = () => {
    onAddJob({
      id: Date.now().toString(),
      title: newJob.title,
      department: newJob.dept,
      location: newJob.location,
      type: '全职',
      status: '发布中',
      applicants: 0,
      description: aiResult
    });
    setShowEditor(false);
    setAiResult('');
    setNewJob({ title: '', dept: '技术部', location: '杭州' });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">招聘工作台</h2>
          <p className="text-slate-500">连接优秀人才，加速组织成长。</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 左侧：职位发布 */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="font-bold text-lg mb-6 flex items-center gap-2"><Briefcase size={20} className="text-indigo-600" /> 快速发布职位</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <input 
                placeholder="职位名称 (如: 后端专家)" 
                className="bg-slate-50 border border-slate-100 px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                value={newJob.title}
                onChange={e => setNewJob({...newJob, title: e.target.value})}
              />
              <select className="bg-slate-50 border border-slate-100 px-4 py-3 rounded-xl outline-none" value={newJob.dept} onChange={e => setNewJob({...newJob, dept: e.target.value})}>
                <option>技术部</option><option>人力资源部</option><option>市场部</option>
              </select>
              <button 
                onClick={handleAiJD}
                disabled={isAiLoading}
                className="bg-indigo-600 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-lg"
              >
                {isAiLoading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <Sparkles size={18} />}
                AI 生成 JD
              </button>
            </div>

            {showEditor && (
              <div className="space-y-4 animate-in slide-in-from-top-4 duration-300">
                <textarea 
                  className="w-full h-48 bg-slate-50 border border-slate-100 p-4 rounded-2xl text-sm leading-relaxed text-slate-600"
                  value={aiResult}
                  onChange={e => setAiResult(e.target.value)}
                />
                <div className="flex justify-end gap-3">
                  <button onClick={() => setShowEditor(false)} className="px-6 py-2 bg-slate-100 rounded-xl font-bold">取消</button>
                  <button onClick={publishJob} className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold shadow-lg">立即发布</button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900">活跃职位 ({jobs.length})</h3>
            {jobs.map(job => (
              <div key={job.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center group hover:border-indigo-200 transition-all">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                    <FileText size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold">{job.title}</h4>
                    <div className="flex gap-4 text-xs text-slate-400 mt-1">
                      <span className="flex items-center gap-1"><MapPin size={12}/> {job.location}</span>
                      <span>{job.department}</span>
                      <span className="text-indigo-500 font-bold">{job.applicants} 位申请者</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 text-slate-300 group-hover:text-indigo-600 transition-all"><ChevronRight size={20} /></button>
              </div>
            ))}
          </div>
        </div>

        {/* 右侧：统计助手 */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
            <Bot size={80} className="absolute -bottom-4 -right-4 text-white/5 rotate-12" />
            <h3 className="text-xl font-bold mb-4">AI 招聘助手</h3>
            <div className="space-y-4 text-sm text-indigo-100">
              <div className="bg-white/10 p-4 rounded-xl border border-white/10">
                <p className="font-bold text-white mb-2">本周洞察：</p>
                技术部职位点击率提升 15%，建议通过内推渠道增加候选人多样性。
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                <span>当前有 3 份简历需要 AI 筛选</span>
              </div>
            </div>
            <button className="w-full mt-6 py-3 bg-white text-slate-900 rounded-xl font-bold hover:bg-indigo-50 transition-all">
              进入 AI 筛选流程
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recruitment;
