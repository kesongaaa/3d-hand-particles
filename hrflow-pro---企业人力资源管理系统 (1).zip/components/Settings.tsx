
import React, { useState, useMemo } from 'react';
import { Settings as SettingsIcon, Shield, Bell, Globe, Database, Save, ListChecks, CheckSquare, Square, AlertCircle, ChevronUp, ChevronDown } from 'lucide-react';
import { FieldSetting } from '../types';

interface Props {
  fieldSettings: FieldSetting[];
  onUpdateFieldSettings: (settings: FieldSetting[]) => void;
}

const Settings: React.FC<Props> = ({ fieldSettings, onUpdateFieldSettings }) => {
  const [activeSubTab, setActiveSubTab] = useState<'general' | 'fields' | 'security'>('general');

  const sortedFields = useMemo(() => {
    return [...fieldSettings].sort((a, b) => a.order - b.order);
  }, [fieldSettings]);

  const handleToggleRequired = (key: string) => {
    const newSettings = fieldSettings.map(f => 
      f.key === key ? { ...f, required: !f.required } : f
    );
    onUpdateFieldSettings(newSettings);
  };

  const moveField = (index: number, direction: 'up' | 'down') => {
    const fields = [...sortedFields];
    if (direction === 'up' && index > 0) {
      [fields[index].order, fields[index - 1].order] = [fields[index - 1].order, fields[index].order];
    } else if (direction === 'down' && index < fields.length - 1) {
      [fields[index].order, fields[index + 1].order] = [fields[index + 1].order, fields[index].order];
    } else {
      return;
    }
    
    // 将更新后的 order 同步回全局设置并通知父组件
    const updatedSettings = fieldSettings.map(f => {
      const updated = fields.find(sf => sf.key === f.key);
      return updated ? { ...f, order: updated.order } : f;
    });
    onUpdateFieldSettings(updatedSettings);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">系统设置</h2>
          <p className="text-slate-500">配置全局参数与入职字段必填、显示顺序。</p>
        </div>
        <button className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-indigo-100">
          <Save size={18} /> 保存配置
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        <aside className="w-full md:w-64 bg-slate-50/50 border-r border-slate-100 p-4 space-y-2">
          <button 
            onClick={() => setActiveSubTab('general')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeSubTab === 'general' ? 'bg-white shadow-sm border border-slate-200 text-indigo-600' : 'text-slate-500 hover:bg-white'}`}
          >
            <Globe size={18} /> 通用设置
          </button>
          <button 
            onClick={() => setActiveSubTab('fields')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeSubTab === 'fields' ? 'bg-white shadow-sm border border-slate-200 text-indigo-600' : 'text-slate-500 hover:bg-white'}`}
          >
            <ListChecks size={18} /> 字段属性与排序
          </button>
          <button 
            onClick={() => setActiveSubTab('security')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeSubTab === 'security' ? 'bg-white shadow-sm border border-slate-200 text-indigo-600' : 'text-slate-500 hover:bg-white'}`}
          >
            <Shield size={18} /> 权限管理
          </button>
        </aside>

        <main className="flex-1 p-10 overflow-y-auto custom-scrollbar">
          {activeSubTab === 'general' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <section>
                <h4 className="text-lg font-bold text-slate-900 mb-6">企业基本信息</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">企业全称</label>
                    <input type="text" defaultValue="HRFlow Pro 科技有限公司" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">默认时区</label>
                    <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none">
                      <option>(GMT+08:00) 北京, 上海</option>
                    </select>
                  </div>
                </div>
              </section>
              <section className="pt-8 border-t border-slate-100">
                 <h4 className="text-lg font-bold text-slate-900 mb-4">AI 辅助设置</h4>
                 <div className="flex items-center justify-between p-5 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                   <div>
                     <p className="font-bold text-slate-900 text-sm">启用 Gemini AI 智能审计</p>
                     <p className="text-xs text-slate-500 mt-1">自动对薪资报表和员工表现进行异常分析</p>
                   </div>
                   <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer group">
                     <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                   </div>
                 </div>
              </section>
            </div>
          )}

          {activeSubTab === 'fields' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div>
                <h4 className="text-lg font-bold text-slate-900">入职字段必填项与显示顺序设置</h4>
                <p className="text-sm text-slate-500 mt-1">设置后，员工档案表单及花名册表格列将遵循此必填逻辑及显示顺序。</p>
              </div>
              
              <div className="space-y-3">
                {sortedFields.map((field, index) => (
                  <div 
                    key={field.key}
                    className="flex items-center gap-4 group"
                  >
                    <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => moveField(index, 'up')}
                        disabled={index === 0}
                        className="p-1 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded disabled:opacity-30"
                      >
                        <ChevronUp size={16} />
                      </button>
                      <button 
                        onClick={() => moveField(index, 'down')}
                        disabled={index === sortedFields.length - 1}
                        className="p-1 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded disabled:opacity-30"
                      >
                        <ChevronDown size={16} />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => handleToggleRequired(field.key)}
                      className={`flex-1 flex items-center justify-between p-5 rounded-2xl border transition-all text-left ${field.required ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-slate-100 hover:border-slate-200 shadow-sm'}`}
                    >
                      <div className="flex items-center gap-3">
                        {field.required ? <CheckSquare className="text-indigo-600" size={20} /> : <Square className="text-slate-300" size={20} />}
                        <div>
                          <span className={`text-sm font-bold ${field.required ? 'text-indigo-900' : 'text-slate-700'}`}>{field.label}</span>
                          <span className="text-[10px] ml-2 text-slate-400 font-mono">#{field.key}</span>
                        </div>
                      </div>
                      {field.required && <span className="text-[10px] font-bold bg-indigo-600 text-white px-2 py-0.5 rounded uppercase tracking-tighter">必填项</span>}
                    </button>
                  </div>
                ))}
              </div>
              
              <div className="p-6 bg-amber-50 rounded-2xl border border-amber-100 flex gap-4">
                <AlertCircle className="text-amber-500 shrink-0" size={20} />
                <p className="text-xs text-amber-800 leading-relaxed">
                  温馨提示：修改排序和必填规则将即时影响“员工管理”模块的入职表单和花名册列排序。建议将关键身份信息（如姓名、身份证、手机号）排在首部。
                </p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Settings;
