
import React, { useState } from 'react';
import { MOCK_ATTENDANCE } from '../constants';
import { Clock, Calendar, CheckCircle, AlertTriangle, MapPin } from 'lucide-react';

const Attendance: React.FC = () => {
  const [hasCheckedIn, setHasCheckedIn] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">考勤管理</h2>
          <p className="text-slate-500">实时记录出勤情况，维护工作纪律。</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-indigo-600">09:41</p>
          <p className="text-sm text-slate-400">2024年5月21日 星期二</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center">
          <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mb-4 animate-pulse">
            <Clock size={40} />
          </div>
          <h3 className="text-xl font-bold mb-2">当前未打卡</h3>
          <p className="text-sm text-slate-500 mb-6 flex items-center gap-1">
            <MapPin size={14} /> 办公地点：杭州研发中心
          </p>
          <button 
            onClick={() => setHasCheckedIn(true)}
            disabled={hasCheckedIn}
            className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all ${
              hasCheckedIn ? 'bg-emerald-500 cursor-default' : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95'
            }`}
          >
            {hasCheckedIn ? '签到成功' : '立即打卡签到'}
          </button>
        </div>

        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex justify-between items-center">
            <h3 className="font-bold flex items-center gap-2">
              <Calendar size={18} className="text-indigo-500" />
              最近考勤记录
            </h3>
            <button className="text-sm text-indigo-600 font-medium">查看全部</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                  <th className="px-6 py-4">日期</th>
                  <th className="px-6 py-4">签到时间</th>
                  <th className="px-6 py-4">签退时间</th>
                  <th className="px-6 py-4">状态</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {MOCK_ATTENDANCE.map(record => (
                  <tr key={record.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium">{record.date}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">{record.checkIn}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">{record.checkOut}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                        record.status === '正常' ? 'bg-emerald-50 text-emerald-600' : 
                        record.status === '迟到' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                      }`}>
                        {record.status === '正常' ? <CheckCircle size={12} /> : <AlertTriangle size={12} />}
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Attendance;
