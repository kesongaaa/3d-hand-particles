
import React, { useState } from 'react';
import { INITIAL_EMPLOYEES } from '../constants';
import { Award, Zap, Star, MessageSquare, TrendingUp, Sparkles, Loader2 } from 'lucide-react';
import { generatePerformanceFeedback } from '../services/geminiService';
import { AIDialog } from './Dashboard';

const Performance: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [aiFeedback, setAiFeedback] = useState<string | null>(null);
  const [selectedEmpName, setSelectedEmpName] = useState<string>('');

  const handleGenerateFeedback = async (empName: string) => {
    setSelectedEmpName(empName);
    setLoading(true);
    try {
      const metrics = { name: empName, kpi: "95%", project_count: 5, quality: "A" };
      const feedback = await generatePerformanceFeedback(metrics);
      setAiFeedback(feedback);
    } catch (e) {
      alert("AI 生成失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">绩效考核</h2>
          <p className="text-slate-500">科学评估员工贡献，驱动人才成长。</p>
        </div>
        <div className="flex gap-2">
          <select className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none">
            <option>2024 第一季度 (Q1)</option>
            <option>2023 年度考核</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp size={18} className="text-indigo-500" /> 员工 KPI 进度
          </h3>
          {INITIAL_EMPLOYEES.slice(0, 10).map(emp => (
            <div key={emp.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm group hover:border-indigo-200 transition-colors">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-slate-600">
                    {emp.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 text-sm">{emp.name}</p>
                    <p className="text-xs text-slate-500">{emp.position}</p>
                  </div>
                </div>
                <button 
                  onClick={() => handleGenerateFeedback(emp.name)}
                  disabled={loading && selectedEmpName === emp.name}
                  className="text-xs bg-indigo-50 text-indigo-700 px-3 py-1.5 rounded-lg font-bold hover:bg-indigo-600 hover:text-white transition-all flex items-center gap-1 disabled:opacity-50"
                >
                  {loading && selectedEmpName === emp.name ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                  AI 评价
                </button>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-tighter">
                  <span>目标达成率</span>
                  <span className="text-indigo-600">85%</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 rounded-full w-[85%]"></div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-slate-900 rounded-3xl p-8 text-white flex flex-col justify-between relative overflow-hidden shadow-2xl h-fit sticky top-8">
           <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl"></div>
           <div className="relative z-10">
             <div className="flex items-center gap-3 mb-6">
               <Zap className="text-amber-400" />
               <h3 className="text-xl font-bold">AI 智能辅导助手</h3>
             </div>
             
             <div className="py-10 text-center">
                <MessageSquare size={48} className="mx-auto text-white/10 mb-4" />
                <p className="text-indigo-200 text-sm">点击左侧员工评价按钮，<br/>获取专业的绩效面谈参考意见。</p>
             </div>
           </div>

           <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-between text-xs text-indigo-300">
             <span>支持多维度能力评估</span>
             <div className="flex gap-1">
               <Star size={12} className="fill-current text-amber-400" />
               <Star size={12} className="fill-current text-amber-400" />
               <Star size={12} className="fill-current text-amber-400" />
             </div>
           </div>
        </div>
      </div>

      {/* AI 辅导建议对话框 */}
      {aiFeedback && (
        <AIDialog 
          title={`${selectedEmpName} 绩效辅导建议`} 
          content={aiFeedback} 
          onClose={() => setAiFeedback(null)} 
        />
      )}
    </div>
  );
};

export default Performance;
