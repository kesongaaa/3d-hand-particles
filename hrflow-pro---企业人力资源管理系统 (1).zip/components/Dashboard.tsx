
import React, { useMemo, useState, useEffect } from 'react';
import { 
  Users, UserPlus, Clock, Target, 
  ArrowUpRight, ArrowDownRight, TrendingUp,
  Sparkles, Loader2, Info, FileText, X, Bot, Zap,
  BrainCircuit, ChevronDown, CheckCircle2, AlertCircle,
  CalendarClock, BellRing, ChevronRight
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, AreaChart, Area,
  Cell, PieChart, Pie
} from 'recharts';
import { Employee, JobPost, ApprovalRequest } from '../types';
import { analyzeDashboardMetric, analyzeDashboardTrend } from '../services/geminiService';

interface DashboardProps {
  employees: Employee[];
  jobs: JobPost[];
  approvals: ApprovalRequest[];
}

const COLORS = ['#4f46e5', '#818cf8', '#a5b4fc', '#c7d2fe', '#e0e7ff'];

// 通用 AI 分析对话框组件 - 增强深度思考过程版
export const AIDialog = ({ title, content, onClose }: { title: string, content: string, onClose: () => void }) => {
  const [displayedText, setDisplayedText] = useState('');
  const [isAnimatingOut, setIsAnimatingOut] = useState(false);
  const [phase, setPhase] = useState<'thinking' | 'result'>('thinking');
  const [thinkingStep, setThinkingStep] = useState(0);

  const thinkingSteps = [
    "正在扫描实时组织数据...",
    "正在构建多维度人才画像模型...",
    "对比行业基准与历年趋势...",
    "生成针对性优化策略..."
  ];

  useEffect(() => {
    if (phase === 'thinking') {
      const stepInterval = setInterval(() => {
        setThinkingStep(prev => {
          if (prev >= thinkingSteps.length - 1) {
            clearInterval(stepInterval);
            setTimeout(() => setPhase('result'), 800);
            return prev;
          }
          return prev + 1;
        });
      }, 600);
      return () => clearInterval(stepInterval);
    }
  }, [phase]);

  useEffect(() => {
    if (phase === 'result') {
      let index = 0;
      const interval = 15; 
      
      const typeWriter = () => {
        if (index < content.length && !isAnimatingOut) {
          setDisplayedText(content.slice(0, index + 1));
          index++;
          setTimeout(typeWriter, interval + Math.random() * 10);
        }
      };
      
      const timer = setTimeout(typeWriter, 100); 
      return () => clearTimeout(timer);
    }
  }, [phase, content, isAnimatingOut]);

  const handleClose = () => {
    setIsAnimatingOut(true);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  return (
    <div 
      className={`fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/40 ${isAnimatingOut ? 'animate-backdrop-exit' : 'animate-backdrop'}`}
      onClick={handleClose}
    >
      <div 
        className={`bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/20 ${isAnimatingOut ? 'animate-ai-exit' : 'animate-ai-entrance'}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部 */}
        <div className="bg-indigo-600 p-8 text-white relative">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
          <div className="flex justify-between items-start relative z-10">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md shadow-inner ai-pulse">
                <Bot size={28} />
              </div>
              <div>
                <h3 className="text-xl font-black tracking-tight">{title} · AI 专家</h3>
                <p className="text-indigo-100 text-[10px] font-bold uppercase tracking-widest mt-1 opacity-70">Gemini 3.0 Deep Reasoning</p>
              </div>
            </div>
            <button onClick={handleClose} className="p-2 hover:bg-white/20 rounded-xl transition-all">
              <X size={24} />
            </button>
          </div>
        </div>
        
        {/* 内容区 */}
        <div className="p-10">
          <div className="space-y-6">
            {/* 思考过程区域 */}
            <div className={`p-5 rounded-2xl border transition-all duration-500 ${phase === 'thinking' ? 'bg-slate-50 border-indigo-100' : 'bg-emerald-50/30 border-emerald-100'}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  {phase === 'thinking' ? (
                    <BrainCircuit className="text-indigo-500 animate-pulse" size={18} />
                  ) : (
                    <CheckCircle2 className="text-emerald-500" size={18} />
                  )}
                  <span className={`text-xs font-bold uppercase tracking-wider ${phase === 'thinking' ? 'text-indigo-600' : 'text-emerald-600'}`}>
                    {phase === 'thinking' ? 'AI 深度思考中' : '思考链分析完成'}
                  </span>
                </div>
                {phase === 'thinking' && (
                  <div className="flex gap-1">
                    <span className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce"></span>
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                {thinkingSteps.map((step, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-center gap-2 text-[11px] font-medium transition-all duration-300 ${
                      idx < thinkingStep ? 'text-emerald-600 opacity-100' : 
                      idx === thinkingStep ? 'text-indigo-600 opacity-100' : 'text-slate-300 opacity-50'
                    }`}
                  >
                    <div className={`w-1 h-1 rounded-full ${idx <= thinkingStep ? 'bg-current' : 'bg-slate-200'}`}></div>
                    {step}
                  </div>
                ))}
              </div>
            </div>

            {/* 最终结果区域 */}
            {phase === 'result' && (
              <div className="animate-in fade-in slide-in-from-top-2 duration-700">
                <div className="flex gap-4 items-start">
                  <div className="mt-1 p-2 bg-indigo-50 rounded-lg shrink-0">
                    <Zap className="text-indigo-600 fill-indigo-600" size={20} />
                  </div>
                  <div className="text-slate-700 leading-relaxed font-medium text-sm whitespace-pre-wrap min-h-[80px]">
                    {displayedText}
                    {displayedText.length < content.length && !isAnimatingOut && (
                      <span className="inline-block w-1.5 h-4 ml-1 bg-indigo-500 animate-pulse align-middle"></span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <button 
            onClick={handleClose}
            className={`w-full mt-10 py-4 rounded-2xl font-bold shadow-xl transition-all flex items-center justify-center gap-2 active:scale-[0.98] ${
              phase === 'result' 
              ? 'bg-indigo-600 text-white shadow-indigo-100 hover:bg-indigo-700' 
              : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'
            }`}
          >
            <Sparkles size={18} />
            {phase === 'thinking' ? '分析中...' : '采纳诊断建议'}
          </button>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, change, icon: Icon, isPositive, onShowInsight }: any) => {
  const [loading, setLoading] = useState(false);

  const handleAiDiagnose = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (loading) return;
    setLoading(true);
    try {
      const insight = await analyzeDashboardMetric(title, value, `当前较上月${isPositive ? '增长' : '下降'}了 ${change}`);
      onShowInsight(title, insight);
    } catch (err) {
      alert('AI 诊断暂时不可用');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm transition-all hover:shadow-xl hover:border-indigo-100 group relative overflow-hidden">
      <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-50 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500 -z-0"></div>
      <div className="flex justify-between items-start relative z-10">
        <div>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{title}</p>
          <h3 className="text-3xl font-black mt-2 text-slate-900">{value}</h3>
          <div className={`flex items-center gap-1 mt-2 text-xs font-bold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
            {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            <span>较上月 {change}</span>
          </div>
        </div>
        <div className="flex flex-col gap-2 items-end">
          <div className="p-3 bg-slate-50 rounded-2xl text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
            <Icon size={24} />
          </div>
          <button 
            onClick={handleAiDiagnose}
            className="p-1.5 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
            title="AI 智能诊断"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
          </button>
        </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ employees, jobs, approvals }) => {
  const [chartLoading, setChartLoading] = useState<{ [key: string]: boolean }>({});
  const [activeInsight, setActiveInsight] = useState<{ title: string; content: string } | null>(null);

  // 1. 核心指标动态计算
  const stats = useMemo(() => ({
    totalEmployees: employees.length,
    openPositions: jobs.filter(j => j.status === '发布中').length,
    pendingApprovals: approvals.filter(a => a.status === '待审批').length,
    activeEmployees: employees.filter(e => e.status === '在职').length,
  }), [employees, jobs, approvals]);

  // 2. 智能提醒逻辑 (转正提醒 & 合同到期提醒)
  const smartAlerts = useMemo(() => {
    const alerts: { id: string, type: 'probation' | 'contract', title: string, subtitle: string, date: string, severity: 'high' | 'medium' }[] = [];
    const today = new Date();
    const oneWeekLater = new Date();
    oneWeekLater.setDate(today.getDate() + 7);
    // Fixed: variable name cannot start with a digit
    const fortyFiveDaysLater = new Date();
    fortyFiveDaysLater.setDate(today.getDate() + 45);

    employees.forEach(emp => {
      if (emp.status === '在职') {
        // 合同到期提醒 (提前 1.5 个月/45天)
        if (emp.contractEndDate) {
          const contractEnd = new Date(emp.contractEndDate);
          // Fixed: renaming variable and using .getTime() for reliable comparison
          if (contractEnd.getTime() >= today.getTime() && contractEnd.getTime() <= fortyFiveDaysLater.getTime()) {
            alerts.push({
              id: `contract-${emp.id}`,
              type: 'contract',
              title: `${emp.name} · 合同即将到期`,
              subtitle: `部门: ${emp.department}`,
              date: emp.contractEndDate,
              severity: contractEnd.getTime() <= oneWeekLater.getTime() ? 'high' : 'medium'
            });
          }
        }

        // 转正提醒 (提前 1 周预警，以及 2/4/6 个月阶段提醒)
        if (emp.permanentDate) {
          const permDate = new Date(emp.permanentDate);
          const joinDate = new Date(emp.joinDate);
          
          // 转正预警 (提前 1 周)
          if (permDate.getTime() >= today.getTime() && permDate.getTime() <= oneWeekLater.getTime()) {
            alerts.push({
              id: `perm-${emp.id}`,
              type: 'probation',
              title: `${emp.name} · 转正节点预警`,
              subtitle: `正式转正日期: ${emp.permanentDate}`,
              date: emp.permanentDate,
              severity: 'high'
            });
          }

          // 阶段性节点提醒 (每两个月一次，一共六个月)
          if (emp.type === '试用期') {
             const diffMonths = (today.getFullYear() - joinDate.getFullYear()) * 12 + (today.getMonth() - joinDate.getMonth());
             if ([2, 4, 6].includes(diffMonths)) {
                // 如果刚好是这两个月的周期，且本月还没过完
                alerts.push({
                  id: `milestone-${emp.id}-${diffMonths}`,
                  type: 'probation',
                  title: `${emp.name} · 入职 ${diffMonths} 个月评估`,
                  subtitle: `当前处于试用期关键考察节点`,
                  date: today.toISOString().split('T')[0],
                  severity: 'medium'
                });
             }
          }
        }
      }
    });

    return alerts.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [employees]);

  // 3. 入职趋势动态计算
  const joiningTrend = useMemo(() => {
    const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
    const currentMonth = new Date().getMonth();
    const result = months.slice(0, currentMonth + 1).map(m => ({ name: m, value: 0 }));
    
    employees.forEach(emp => {
      const date = new Date(emp.joinDate);
      const mIdx = date.getMonth();
      if (mIdx <= currentMonth) {
        result[mIdx].value += 1;
      }
    });
    return result;
  }, [employees]);

  // 4. 部门分布动态计算
  const deptDistribution = useMemo(() => {
    const counts: Record<string, number> = {};
    employees.forEach(emp => {
      counts[emp.department] = (counts[emp.department] || 0) + 1;
    });
    return Object.entries(counts).map(([name, count]) => ({ name, value: count }));
  }, [employees]);

  const handleShowInsight = (title: string, content: string) => {
    setActiveInsight({ title, content });
  };

  const handleChartAiInsight = async (chartName: string, data: any[]) => {
    if (chartLoading[chartName]) return;
    setChartLoading(prev => ({ ...prev, [chartName]: true }));
    try {
      const insight = await analyzeDashboardTrend(chartName, data);
      setActiveInsight({ title: chartName, content: insight });
    } catch (err) {
      alert('无法生成趋势洞察');
    } finally {
      setChartLoading(prev => ({ ...prev, [chartName]: false }));
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">企业数字化概览</h2>
          <p className="text-slate-500 font-medium mt-1">基于当前系统 <span className="text-indigo-600 font-bold">{employees.length}</span> 名员工的实时数据建模。</p>
        </div>
        <button className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center gap-2 active:scale-95">
          <TrendingUp size={18} />
          生成全量 AI 运营周报
        </button>
      </header>

      {/* 动态指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="实时员工总数" value={stats.totalEmployees} change="+8.2%" icon={Users} isPositive={true} onShowInsight={handleShowInsight} />
        <StatCard title="发布中职位" value={stats.openPositions} change="+12%" icon={Target} isPositive={true} onShowInsight={handleShowInsight} />
        <StatCard title="待处理审批" value={stats.pendingApprovals} change="-24%" icon={FileText} isPositive={false} onShowInsight={handleShowInsight} />
        <StatCard title="人才库候选人" value="156" change="+4%" icon={UserPlus} isPositive={true} onShowInsight={handleShowInsight} />
      </div>

      {/* 智能提醒中心 */}
      {smartAlerts.length > 0 && (
        <section className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl animate-in slide-in-from-top-4 duration-500">
           <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
           <div className="flex items-center justify-between mb-8 relative z-10">
              <div className="flex items-center gap-4">
                 <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md">
                    <BellRing className="text-amber-400 animate-bounce" size={24} />
                 </div>
                 <div>
                    <h4 className="text-xl font-bold tracking-tight">智能提醒中心</h4>
                    <p className="text-indigo-200/60 text-xs font-bold uppercase tracking-widest mt-0.5">Automated Lifecycle Alerts</p>
                 </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                 <span>{smartAlerts.length} 条待处理提醒</span>
                 <ChevronRight size={14} />
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
              {smartAlerts.slice(0, 6).map(alert => (
                 <div key={alert.id} className="bg-white/5 border border-white/10 p-5 rounded-3xl hover:bg-white/10 transition-all group flex flex-col justify-between min-h-[140px]">
                    <div className="flex justify-between items-start">
                       <div className={`p-2 rounded-xl ${alert.type === 'probation' ? 'bg-amber-500/20 text-amber-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                          {alert.type === 'probation' ? <CalendarClock size={20} /> : <FileText size={20} />}
                       </div>
                       {alert.severity === 'high' && (
                          <span className="flex items-center gap-1 text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full uppercase tracking-tighter">
                             <AlertCircle size={10} /> 紧急
                          </span>
                       )}
                    </div>
                    <div>
                       <h5 className="font-bold text-sm mt-4 text-white group-hover:text-indigo-300 transition-colors line-clamp-1">{alert.title}</h5>
                       <p className="text-white/40 text-xs mt-1 truncate">{alert.subtitle}</p>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                       <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest">{alert.date}</span>
                       <button className="text-[10px] font-bold text-indigo-400 hover:text-white transition-colors">立即处理</button>
                    </div>
                 </div>
              ))}
           </div>
        </section>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 入职趋势 */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col relative overflow-hidden">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h4 className="font-black text-xl text-slate-900">入职趋势分析</h4>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest font-bold">Joining Trends (Current Year)</p>
            </div>
            <button 
              onClick={() => handleChartAiInsight('入职趋势', joiningTrend)}
              className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-4 py-2 rounded-xl text-xs font-bold hover:bg-indigo-600 hover:text-white transition-all shadow-sm active:scale-95"
            >
              {chartLoading['入职趋势'] ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
              AI 趋势洞察
            </button>
          </div>

          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={joiningTrend}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontWeight: 'bold'}}
                />
                <Area type="monotone" dataKey="value" stroke="#4f46e5" strokeWidth={4} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 部门分布 */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-8">
            <h4 className="font-black text-xl text-slate-900">部门人员占比</h4>
            <button 
              onClick={() => handleChartAiInsight('部门分布', deptDistribution)}
              className="p-2 text-indigo-600 bg-indigo-50 rounded-xl hover:bg-indigo-600 hover:text-white transition-all active:scale-95"
            >
              {chartLoading['部门分布'] ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
            </button>
          </div>

          <div className="h-[250px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deptDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {deptDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-2xl font-black text-slate-900">{stats.totalEmployees}</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase">总人数</span>
            </div>
          </div>

          <div className="mt-8 space-y-3">
            {deptDistribution.map((dept, index) => (
              <div key={dept.name} className="flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[index % COLORS.length]}}></div>
                  <span className="text-sm font-bold text-slate-600 group-hover:text-slate-900 transition-colors">{dept.name}</span>
                </div>
                <span className="text-sm font-black text-slate-900">{(dept.value / stats.totalEmployees * 100).toFixed(1)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI 分析对话框 */}
      {activeInsight && (
        <AIDialog 
          title={activeInsight.title} 
          content={activeInsight.content} 
          onClose={() => setActiveInsight(null)} 
        />
      )}
    </div>
  );
};

export default Dashboard;
