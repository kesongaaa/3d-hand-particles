
import React, { useState } from 'react';
import { ApprovalRequest } from '../types';
import { Check, X, Plus, Clock, FileText, Send } from 'lucide-react';

interface Props {
  approvals: ApprovalRequest[];
  onAction: (id: string, status: '已通过' | '已驳回') => void;
  onSubmit: (req: Partial<ApprovalRequest>) => void;
}

const Approvals: React.FC<Props> = ({ approvals, onAction, onSubmit }) => {
  const [showApply, setShowApply] = useState(false);
  const [newRequest, setNewRequest] = useState({ type: '请假', content: '' });

  const submitApply = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      id: Date.now().toString(),
      type: newRequest.type as any,
      content: newRequest.content,
      applicantName: '张伟', // 模拟当前登录用户
      applicantId: 'e1',
      date: new Date().toISOString().split('T')[0],
      status: '待审批'
    });
    setShowApply(false);
    setNewRequest({ type: '请假', content: '' });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">流程中心</h2>
          <p className="text-slate-500">统一管控各类流程申请与审批。</p>
        </div>
        <button 
          onClick={() => setShowApply(true)}
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-100"
        >
          <Plus size={18}/> 发起新申请
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
             <div className="p-6 border-b border-slate-50 flex gap-6">
               <button className="text-indigo-600 font-bold relative pb-1 after:absolute after:bottom-0 after:left-0 after:w-full after:h-1 after:bg-indigo-600 after:rounded-full">
                 待我审批 ({approvals.filter(a => a.status === '待审批').length})
               </button>
               <button className="text-slate-400 font-medium hover:text-slate-600 transition-colors">我发起的</button>
             </div>
             
             <div className="divide-y divide-slate-50">
               {approvals.map(app => (
                 <div key={app.id} className="p-6 hover:bg-slate-50/50 transition-all flex justify-between items-center group">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                        app.type === '请假' ? 'bg-amber-50 text-amber-500' : 
                        app.type === '报销' ? 'bg-emerald-50 text-emerald-500' : 'bg-indigo-50 text-indigo-500'
                      }`}>
                        <FileText size={24} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-900">{app.applicantName} 提交的{app.type}申请</h4>
                          <span className="bg-slate-100 text-slate-400 text-[10px] px-2 py-0.5 rounded uppercase font-bold">{app.date}</span>
                        </div>
                        <p className="text-sm text-slate-500 mt-1">{app.content}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      {app.status === '待审批' ? (
                        <>
                          <button onClick={() => onAction(app.id, '已驳回')} className="p-2 bg-slate-100 text-slate-400 hover:bg-rose-500 hover:text-white rounded-xl transition-all"><X size={20}/></button>
                          <button onClick={() => onAction(app.id, '已通过')} className="p-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl shadow-lg transition-all"><Check size={20}/></button>
                        </>
                      ) : (
                        <span className={`px-4 py-1.5 rounded-xl text-xs font-bold ${
                          app.status === '已通过' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                        }`}>{app.status}</span>
                      )}
                    </div>
                 </div>
               ))}
             </div>
          </div>
        </div>

        {/* 右侧：快捷申请栏 */}
        <div className="space-y-6">
          {showApply ? (
            <div className="bg-white p-8 rounded-3xl border-2 border-indigo-500 shadow-2xl animate-in zoom-in-95 duration-200">
               <h3 className="text-xl font-bold mb-6">填报申请</h3>
               <form onSubmit={submitApply} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-400 mb-2 block uppercase">申请类别</label>
                    <select value={newRequest.type} onChange={e => setNewRequest({...newRequest, type: e.target.value})} className="w-full bg-slate-50 border border-slate-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500">
                      <option>请假</option><option>报销</option><option>加班</option><option>转正</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 mb-2 block uppercase">详细描述</label>
                    <textarea value={newRequest.content} onChange={e => setNewRequest({...newRequest, content: e.target.value})} required className="w-full h-32 bg-slate-50 border border-slate-100 p-4 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" placeholder="请详细说明原因及日期..."/>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setShowApply(false)} type="button" className="flex-1 bg-slate-100 py-3 rounded-xl font-bold">取消</button>
                    <button type="submit" className="flex-[2] bg-indigo-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg hover:bg-indigo-700">
                      <Send size={18} /> 提交申请
                    </button>
                  </div>
               </form>
            </div>
          ) : (
            <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
               <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mb-4">
                 <Clock size={24} />
               </div>
               <h4 className="font-bold text-indigo-900 mb-2 text-lg">智能任务处理</h4>
               <p className="text-sm text-indigo-700 leading-relaxed mb-6 opacity-80">当前您还有 3 个待办流程尚未处理，建议在今日下班前完成审批工作以维持流程效率。</p>
               <button onClick={() => setShowApply(true)} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200">发起申请</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Approvals;
