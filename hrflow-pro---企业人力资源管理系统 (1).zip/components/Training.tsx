
import React from 'react';
import { MOCK_COURSES } from '../constants';
import { GraduationCap, PlayCircle, BookOpen, Users, Clock } from 'lucide-react';

const Training: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">培训与发展</h2>
          <p className="text-slate-500">赋能员工，打造持续学习型组织。</p>
        </div>
        <button className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all">
          进入课程商城
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_COURSES.map(course => (
          <div key={course.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden group hover:shadow-md transition-all">
            <div className="h-32 bg-slate-900 flex items-center justify-center text-white relative">
               <BookOpen size={48} className="opacity-20 absolute" />
               <span className="bg-indigo-600 px-3 py-1 rounded-full text-[10px] font-bold absolute top-4 right-4 uppercase tracking-widest">{course.category}</span>
               <h4 className="text-lg font-bold px-6 text-center z-10">{course.title}</h4>
            </div>
            <div className="p-6">
               <div className="flex justify-between items-center text-xs text-slate-500 mb-4 font-bold">
                 <div className="flex items-center gap-1"><Users size={14}/> {course.instructor}</div>
                 <div className="flex items-center gap-1"><Clock size={14}/> 4.5 小时</div>
               </div>
               <div className="space-y-2 mb-6">
                 <div className="flex justify-between text-xs font-bold text-slate-400">
                   <span>学习进度</span>
                   <span className="text-indigo-600">{course.progress}%</span>
                 </div>
                 <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                   <div className="h-full bg-indigo-500 rounded-full" style={{width: `${course.progress}%`}}></div>
                 </div>
               </div>
               <button className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-50 text-slate-700 rounded-xl font-bold group-hover:bg-indigo-600 group-hover:text-white transition-all">
                 <PlayCircle size={18} /> 继续学习
               </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Training;
