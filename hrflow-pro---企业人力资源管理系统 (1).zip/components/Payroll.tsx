
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  DollarSign, Wallet, FileUp, Download, CheckCircle, 
  AlertCircle, Table as TableIcon, Sparkles, Loader2, Trash2,
  ChevronLeft, ChevronRight, Save, Calculator, Edit2, Users, ArrowLeft, ClipboardCheck, Calendar
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { auditPayrollData } from '../services/geminiService';
import { AIDialog } from './Dashboard';
import { Employee } from '../types';

interface PayrollProps {
  employees: Employee[];
}

// 定义完整的工资表结构
const PAYROLL_HEADERS = [
  "姓名", "部门", "员工类型", "员工状态", "身份证号", "入职时间", "离职时间",
  "本月出勤天", "计算补助天", "基本工资", "绩效工资", "项目绩效", "销售绩效", "管理绩效",
  "综合补助", "加班费", "其他费用", "司龄奖", "过节费",
  "迟到、早退、缺卡次数", "事假次数", "事假天数", "病假次数", "病假天数", "旷工次数", "丧假天数",
  "假勤扣除", "其他扣除", "扣除总计", "应发工资", "个人社保公积金", "个人所得税", "工会经费", "实发工资（含圈卡金额）", "圈卡金额", "实发工资（不含圈卡金额）"
];

// 扣款相关字段列表，用于展示红色
const DEDUCTION_FIELDS = [
  "迟到、早退、缺卡次数", "事假次数", "事假天数", "病假次数", "病假天数", "旷工次数", "丧假天数",
  "假勤扣除", "其他扣除", "扣除总计", "个人社保公积金", "个人所得税", "工会经费"
];

const Payroll: React.FC<PayrollProps> = ({ employees }) => {
  const [activeMode, setActiveMode] = useState<'main' | 'calc'>('main');
  const [payrollData, setPayrollData] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  
  // 增加月份选择状态，默认为当前月
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // 初始化加载暂存的数据
  useEffect(() => {
    const savedPayroll = localStorage.getItem('hrms_current_payroll_draft');
    if (savedPayroll) {
      try {
        const parsed = JSON.parse(savedPayroll);
        if (parsed && parsed.length > 0) {
          setPayrollData(parsed);
          // 如果有草稿，尝试恢复当时选中的月份
          const savedMonth = localStorage.getItem('hrms_current_payroll_month');
          if (savedMonth) setSelectedMonth(savedMonth);
        }
      } catch (e) {
        console.error("Failed to load payroll draft", e);
      }
    }
  }, []);

  // 核心核算算法：根据图片逻辑自动计算
  const calculateRow = (row: any) => {
    const num = (val: any) => parseFloat(val) || 0;

    // 1. 应发工资 = (基本+绩效系列+补助+加班+其他+司龄+过节) - 假勤扣除
    const grossPay = 
      num(row["基本工资"]) + num(row["绩效工资"]) + num(row["项目绩效"]) + 
      num(row["销售绩效"]) + num(row["管理绩效"]) + num(row["综合补助"]) + 
      num(row["加班费"]) + num(row["其他费用"]) + num(row["司龄奖"]) + 
      num(row["过节费"]) - num(row["假勤扣除"]);

    // 2. 扣除总计 = 个人社保公积金 + 个人所得税 + 工会经费 + 其他扣除
    const totalDeduction = 
      num(row["个人社保公积金"]) + num(row["个人所得税"]) + 
      num(row["工会经费"]) + num(row["其他扣除"]);

    // 3. 实发工资（含圈卡） = 应发工资 - 扣除总计
    const netPayIncludingCard = grossPay - totalDeduction;

    // 4. 实发工资（不含圈卡） = 实发工资（含圈卡） - 圈卡金额
    const finalNetPay = netPayIncludingCard - num(row["圈卡金额"]);

    return {
      ...row,
      "扣除总计": totalDeduction.toFixed(2),
      "应发工资": grossPay.toFixed(2),
      "实发工资（含圈卡金额）": netPayIncludingCard.toFixed(2),
      "实发工资（不含圈卡金额）": finalNetPay.toFixed(2)
    };
  };

  const handleGenerateFromSystem = () => {
    setIsProcessing(true);
    const activeEmployees = employees.filter(e => e.status === '在职');
    
    const initialData = activeEmployees.map(emp => {
      const row: any = {};
      PAYROLL_HEADERS.forEach(header => {
        if (header === "姓名") row[header] = emp.name;
        else if (header === "部门") row[header] = emp.department;
        else if (header === "员工类型") row[header] = emp.type;
        else if (header === "员工状态") row[header] = emp.status;
        else if (header === "身份证号") row[header] = emp.idCard;
        else if (header === "入职时间") row[header] = emp.joinDate;
        else if (header === "基本工资") row[header] = emp.salary || 0;
        else if (header === "离职时间") row[header] = "";
        else row[header] = "0.00";
      });
      return calculateRow(row);
    });

    setPayrollData(initialData);
    setActiveMode('calc');
    setIsProcessing(false);
    // 同时也保存选中的月份到本地
    localStorage.setItem('hrms_current_payroll_month', selectedMonth);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rawData = XLSX.utils.sheet_to_json(ws);
      
      const enrichedData = rawData.map((row: any) => calculateRow(row));
      setPayrollData(enrichedData);
      setActiveMode('calc');
      setIsProcessing(false);
      localStorage.setItem('hrms_current_payroll_month', selectedMonth);
    };
    reader.readAsBinaryString(file);
  };

  const updateCell = (rowIndex: number, key: string, value: string) => {
    setPayrollData(prev => {
      const newData = [...prev];
      newData[rowIndex] = calculateRow({ ...newData[rowIndex], [key]: value });
      return newData;
    });
  };

  const handleAiAudit = async () => {
    if (payrollData.length === 0) return;
    setIsProcessing(true);
    try {
      const report = await auditPayrollData(payrollData);
      setAiReport(report);
    } catch (error) {
      alert('AI 审计失败，请检查网络后重试');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveDraft = () => {
    setSaveStatus('saving');
    localStorage.setItem('hrms_current_payroll_draft', JSON.stringify(payrollData));
    localStorage.setItem('hrms_current_payroll_month', selectedMonth);
    setTimeout(() => {
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 600);
  };

  const clearData = () => {
    if (window.confirm('确定要清除当前核算数据并返回主页吗？')) {
      setPayrollData([]);
      localStorage.removeItem('hrms_current_payroll_draft');
      localStorage.removeItem('hrms_current_payroll_month');
      setAiReport(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setActiveMode('main');
    }
  };

  // 格式化月份显示
  const formattedSelectedMonth = useMemo(() => {
    const [year, month] = selectedMonth.split('-');
    return `${year}年${month}月`;
  }, [selectedMonth]);

  return (
    <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">薪酬福利核算</h2>
          <p className="text-slate-500">
            {activeMode === 'main' ? '完全适配标准财务工资报表结构，支持 AI 异常审计。' : `正在进行 ${formattedSelectedMonth} 薪资预核算...`}
          </p>
        </div>
        {activeMode === 'calc' && (
          <button 
            onClick={() => setActiveMode('main')}
            className="flex items-center gap-2 px-5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all shadow-sm active:scale-95"
          >
            <ArrowLeft size={16} /> 返回薪酬概览
          </button>
        )}
      </div>

      {activeMode === 'main' ? (
        <div className="space-y-6 animate-in slide-in-from-top-2 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm relative overflow-hidden group">
              <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
                <Calculator size={80} />
              </div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">上月实发总额</p>
              <h3 className="text-3xl font-black mt-2 text-slate-900">¥ 1,248,500.00</h3>
              <div className="mt-4 flex items-center gap-2 text-[10px] text-emerald-600 font-bold bg-emerald-50 w-fit px-2 py-1 rounded-lg">
                <CheckCircle size={12} /> 财务出纳已结清
              </div>
            </div>
            
            <div className="bg-indigo-600 p-6 rounded-[2rem] text-white shadow-xl shadow-indigo-100 flex flex-col justify-between group">
              <div>
                <div className="flex justify-between items-start">
                  <p className="text-indigo-100 text-xs font-bold uppercase tracking-widest">待办核算</p>
                  <Calendar size={18} className="text-indigo-200 group-hover:scale-110 transition-transform" />
                </div>
                <div className="mt-4 space-y-1">
                  <label className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest">选择核算月份</label>
                  <input 
                    type="month" 
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm font-bold text-white outline-none focus:bg-white/20 transition-all cursor-pointer"
                  />
                </div>
              </div>
              <button 
                onClick={() => {
                   if (payrollData.length > 0) {
                     setActiveMode('calc');
                   } else {
                     handleGenerateFromSystem();
                   }
                }}
                disabled={isProcessing}
                className="w-full mt-6 py-3 bg-white text-indigo-600 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 hover:bg-white/90 active:scale-95"
              >
                {isProcessing ? <Loader2 size={16} className="animate-spin" /> : <Calculator size={16} />}
                {payrollData.length > 0 ? `继续 ${formattedSelectedMonth} 核算` : `开始 ${formattedSelectedMonth} 核算`}
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
             <div className="p-8 border-b border-slate-50 font-black text-slate-900">历史发放台账</div>
             <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50/50 text-[10px] uppercase font-bold text-slate-400 tracking-widest">
                    <tr>
                      <th className="px-8 py-4">核算月份</th>
                      <th className="px-8 py-4">部门覆盖</th>
                      <th className="px-8 py-4">总额 (应发)</th>
                      <th className="px-8 py-4">状态</th>
                      <th className="px-8 py-4 text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    <tr className="hover:bg-indigo-50/20 transition-all cursor-pointer">
                      <td className="px-8 py-5 text-sm font-bold">2024-04</td>
                      <td className="px-8 py-5 text-sm text-slate-600">全公司 (16个部门)</td>
                      <td className="px-8 py-5 text-sm font-mono font-bold">¥ 1,210,000.00</td>
                      <td className="px-8 py-5"><span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-bold">已发放</span></td>
                      <td className="px-8 py-5 text-right"><button className="text-indigo-600 hover:underline text-sm font-bold">导出报表</button></td>
                    </tr>
                  </tbody>
                </table>
             </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col min-h-0 animate-in slide-in-from-bottom-4 duration-500">
          <div className="flex justify-between items-center mb-4 shrink-0">
            <div className="flex items-center gap-4">
              <h3 className="font-black text-lg flex items-center gap-2 text-slate-900">
                <TableIcon size={20} className="text-indigo-600" /> {formattedSelectedMonth} 核算清单 ({payrollData.length} 人)
              </h3>
              <div className="h-4 w-[1px] bg-slate-200"></div>
              <button 
                onClick={handleAiAudit}
                disabled={isProcessing}
                className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-slate-800 transition-all shadow-lg disabled:opacity-50"
              >
                {isProcessing ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} className="text-amber-400" />}
                AI 逻辑审计
              </button>
              <div className="h-4 w-[1px] bg-slate-200"></div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 text-xs font-bold transition-colors"
              >
                <FileUp size={14} /> 导入外部 Excel
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".xlsx, .xls" className="hidden" />
              </button>
            </div>
            <div className="flex items-center gap-3">
               <button onClick={clearData} className="text-slate-400 hover:text-rose-600 transition-colors p-2" title="清除并返回"><Trash2 size={18} /></button>
               
               <button 
                 onClick={handleSaveDraft}
                 disabled={saveStatus !== 'idle'}
                 className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all border ${
                   saveStatus === 'saved' 
                   ? 'bg-emerald-50 border-emerald-200 text-emerald-600' 
                   : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                 }`}
               >
                 {saveStatus === 'saving' ? <Loader2 size={16} className="animate-spin text-indigo-600" /> : 
                  saveStatus === 'saved' ? <CheckCircle size={16} /> : <Save size={16} className="text-indigo-600" />}
                 {saveStatus === 'saving' ? '正在暂存...' : saveStatus === 'saved' ? '已保存草稿' : '暂存核算数据'}
               </button>

               <button className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-100 flex items-center gap-2 active:scale-95 transition-all hover:bg-indigo-700">
                 <ClipboardCheck size={16} /> 确认并入账
               </button>
            </div>
          </div>

          <div className="flex-1 bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col min-h-0">
            <div className="flex-1 overflow-auto custom-scrollbar custom-scrollbar-horizontal">
              <table className="w-full text-left border-collapse border-separate border-spacing-0">
                <thead className="sticky top-0 z-20 bg-white">
                  <tr className="bg-slate-50/80 backdrop-blur-sm">
                    {PAYROLL_HEADERS.map((header, idx) => (
                      <th 
                        key={idx} 
                        className={`px-4 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 whitespace-nowrap min-w-[120px] ${idx < 2 ? 'sticky left-0 bg-slate-50 z-30' : ''}`}
                        style={idx < 2 ? { left: idx === 0 ? 0 : '120px' } : {}}
                      >
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {payrollData.length > 0 ? (
                    payrollData.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-indigo-50/20 transition-all group">
                        {PAYROLL_HEADERS.map((header, hIdx) => {
                          const isAutoCalc = ["扣除总计", "应发工资", "实发工资（含圈卡金额）", "实发工资（不含圈卡金额）"].includes(header);
                          const isDeduction = DEDUCTION_FIELDS.includes(header);
                          const isNumeric = hIdx > 6; // 从出勤天数开始均为数字
                          const val = row[header] || (isNumeric ? "0.00" : "-");
                          
                          return (
                            <td 
                              key={hIdx} 
                              className={`px-4 py-4 text-sm whitespace-nowrap overflow-hidden text-ellipsis ${hIdx < 2 ? 'sticky left-0 bg-white group-hover:bg-indigo-50 z-10 font-bold' : ''} ${isNumeric ? 'font-mono text-sm' : 'text-slate-600'} ${isAutoCalc ? 'font-bold text-indigo-700 bg-indigo-50/30' : ''} ${isDeduction ? 'text-rose-600' : ''}`}
                              style={hIdx < 2 ? { left: hIdx === 0 ? 0 : '120px' } : {}}
                            >
                              {isAutoCalc ? (
                                `¥${val}`
                              ) : (
                                <input 
                                  className={`w-full bg-transparent border-none outline-none focus:ring-1 focus:ring-indigo-200 rounded px-1 transition-all hover:bg-white ${isNumeric ? 'font-mono' : ''} ${isDeduction ? 'text-rose-600 font-bold' : ''}`}
                                  value={val}
                                  onChange={(e) => updateCell(rIdx, header, e.target.value)}
                                />
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={PAYROLL_HEADERS.length} className="px-8 py-20 text-center text-slate-400">
                        <div className="flex flex-col items-center gap-3">
                          <Users size={40} className="opacity-20" />
                          <p>正在拉取系统在职员工数据...</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center gap-3 shrink-0">
            <Calculator className="text-indigo-500" size={18} />
            <p className="text-xs text-indigo-800 font-medium">核算引擎：系统已自动匹配档案基本工资。您可以点击“暂存核算数据”随时保存当前工作进度，红色字段表示扣款项，系统将即时重算所有层级实发金额。</p>
          </div>
        </div>
      )}

      {aiReport && (
        <AIDialog 
          title="薪资核算智能审计" 
          content={aiReport} 
          onClose={() => setAiReport(null)} 
        />
      )}
    </div>
  );
};

export default Payroll;
