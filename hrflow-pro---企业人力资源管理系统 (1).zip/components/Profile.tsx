
import React from 'react';
import { MOCK_USER } from '../constants';
import { Mail, Phone, MapPin, Edit3, Shield, Award, Calendar } from 'lucide-react';

const Profile: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="relative h-48 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-3xl shadow-lg overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        <div className="absolute bottom-6 left-8 flex items-end gap-6">
          <div className="w-32 h-32 rounded-3xl border-4 border-white bg-slate-200 shadow-2xl overflow-hidden">
            <img src={MOCK_USER.avatar} alt={MOCK_USER.name} className="w-full h-full object-cover" />
          </div>
          <div className="mb-2 text-white">
            <h2 className="text-3xl font-bold">{MOCK_USER.name}</h2>
            <p className="text-indigo-100 flex items-center gap-1 mt-1">
              <Shield size={16} /> {MOCK_USER.department} · {MOCK_USER.position}
            </p>
          </div>
        </div>
        <button className="absolute top-6 right-8 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 border border-white/20">
          <Edit3 size={16} /> 编辑资料
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
              联系方式
            </h3>
            <div className="space-y-5">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">
                  <Mail size={18} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">邮箱地址</p>
                  <p className="text-sm font-medium text-slate-900">{MOCK_USER.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">
                  <Phone size={18} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">手机号码</p>
                  <p className="text-sm font-medium text-slate-900">{MOCK_USER.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">办公地点</p>
                  <p className="text-sm font-medium text-slate-900">{MOCK_USER.address}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500">
                <Award size={24} />
              </div>
              <div>
                <p className="text-2xl font-bold">12</p>
                <p className="text-xs text-slate-500 font-medium">所获勋章/荣誉</p>
              </div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-500">
                <Calendar size={24} />
              </div>
              <div>
                <p className="text-2xl font-bold">842</p>
                <p className="text-xs text-slate-500 font-medium">加入公司天数</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <h3 className="font-bold text-slate-900 mb-6">成长时间轴</h3>
            <div className="space-y-8 relative before:absolute before:inset-0 before:left-[11px] before:w-[2px] before:bg-slate-100">
               <div className="relative pl-8">
                 <div className="absolute left-0 top-1 w-6 h-6 bg-indigo-600 border-4 border-indigo-100 rounded-full z-10"></div>
                 <p className="text-sm font-bold text-slate-900">晋升为 HR 总监</p>
                 <p className="text-xs text-slate-400 mt-1">2024年1月</p>
               </div>
               <div className="relative pl-8">
                 <div className="absolute left-0 top-1 w-6 h-6 bg-slate-200 border-4 border-slate-50 rounded-full z-10"></div>
                 <p className="text-sm font-bold text-slate-700">完成高级人才培训课程</p>
                 <p className="text-xs text-slate-400 mt-1">2023年6月</p>
               </div>
               <div className="relative pl-8">
                 <div className="absolute left-0 top-1 w-6 h-6 bg-slate-200 border-4 border-slate-50 rounded-full z-10"></div>
                 <p className="text-sm font-bold text-slate-700">入职公司</p>
                 <p className="text-xs text-slate-400 mt-1">2022年2月</p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
