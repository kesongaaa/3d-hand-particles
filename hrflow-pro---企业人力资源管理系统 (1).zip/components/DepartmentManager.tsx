
import React, { useState, useRef, useMemo } from 'react';
import { Network, Plus, Trash2, Edit3, UserCheck, Users, X, Save, ChevronRight, ChevronDown } from 'lucide-react';
import { Department, Employee } from '../types';

interface Props {
  employees: Employee[];
  departments: Department[];
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
}

const DepartmentManager: React.FC<Props> = ({ employees, departments, setDepartments }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['root', 'dept-hr']));

  // 递归构建部门树结构
  const departmentTree = useMemo(() => {
    const map = new Map<string, Department & { children: any[] }>();
    const roots: any[] = [];

    departments.forEach(d => {
      map.set(d.id, { ...d, children: [] });
    });

    departments.forEach(d => {
      const node = map.get(d.id)!;
      if (d.parentId && map.has(d.parentId)) {
        map.get(d.parentId)!.children.push(node);
      } else {
        roots.push(node);
      }
    });

    // 对各级子部门进行排序
    const sortNodes = (nodes: any[]) => {
      nodes.sort((a, b) => a.order - b.order);
      nodes.forEach(n => {
        if (n.children.length > 0) sortNodes(n.children);
      });
    };
    sortNodes(roots);

    return roots;
  }, [departments]);

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const getEmpCount = (deptName: string) => {
    return employees.filter(e => e.department === deptName && e.status === '在职').length;
  };

  const handleAddOrEdit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
    const managerName = (form.elements.namedItem('managerName') as HTMLSelectElement).value;
    const parentId = (form.elements.namedItem('parentId') as HTMLSelectElement).value || undefined;

    if (editingDept) {
      setDepartments(prev => prev.map(d => d.id === editingDept.id ? { ...d, name, managerName, parentId } : d));
    } else {
      const newDept: Department = {
        id: `dept-${Date.now()}`,
        name,
        managerName,
        parentId,
        order: departments.filter(d => d.parentId === parentId).length
      };
      setDepartments(prev => [...prev, newDept]);
    }
    setIsModalOpen(false);
    setEditingDept(null);
  };

  const handleDelete = (id: string, name: string) => {
    const hasChildren = departments.some(d => d.parentId === id);
    if (hasChildren) {
      alert(`无法删除！该部门包含子级部门，请先删除或转移子部门。`);
      return;
    }
    const count = getEmpCount(name);
    if (count > 0) {
      alert(`无法删除！“${name}”部门下仍有 ${count} 名在职员工，请先在员工管理中调整。`);
      return;
    }
    if (window.confirm('确定要删除该部门吗？')) {
      setDepartments(prev => prev.filter(d => d.id !== id));
    }
  };

  // 递归渲染表格行
  const renderRows = (nodes: any[], level = 0) => {
    return nodes.flatMap(node => {
      const isExpanded = expandedIds.has(node.id);
      const hasChildren = node.children.length > 0;
      
      const currentRow = (
        <tr key={node.id} className="hover:bg-indigo-50/20 transition-all group border-b border-slate-50">
          <td className="px-6 py-4">
            <div className="flex items-center gap-2" style={{ paddingLeft: `${level * 24}px` }}>
              <div className="w-6 h-6 flex items-center justify-center shrink-0">
                {hasChildren && (
                  <button 
                    onClick={() => toggleExpand(node.id)}
                    className="p-1 hover:bg-slate-100 rounded transition-colors text-slate-400"
                  >
                    {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  </button>
                )}
              </div>
              <span className={`text-sm font-bold ${level === 0 ? 'text-slate-900' : 'text-slate-700'}`}>
                {node.name}
              </span>
            </div>
          </td>
          <td className="px-6 py-4">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              {node.managerName ? (
                <>
                  <UserCheck size={14} className="text-indigo-500" />
                  {node.managerName}
                </>
              ) : (
                <span className="text-slate-300 italic">未设置主管</span>
              )}
            </div>
          </td>
          <td className="px-6 py-4">
            <span className="inline-flex items-center gap-1.5 bg-indigo-50 text-indigo-600 px-3 py-0.5 rounded-full text-[10px] font-bold border border-indigo-100">
              <Users size={12} /> {getEmpCount(node.name)}
            </span>
          </td>
          <td className="px-6 py-4 text-right">
            <div className="flex justify-end gap-2">
              <button 
                onClick={() => { setEditingDept(node); setIsModalOpen(true); }}
                className="p-1.5 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
              >
                <Edit3 size={16} />
              </button>
              {node.id !== 'root' && (
                <button 
                  onClick={() => handleDelete(node.id, node.name)}
                  className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </td>
        </tr>
      );

      return [
        currentRow,
        ...(isExpanded && hasChildren ? renderRows(node.children, level + 1) : [])
      ];
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">组织架构管理</h2>
          <p className="text-slate-500">维护企业部门纵向层级，支持折叠查看与层级管理。</p>
        </div>
        <button 
          onClick={() => { setEditingDept(null); setIsModalOpen(true); }}
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
        >
          <Plus size={18} /> 新增部门
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-100">
                <th className="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">部门名称</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">部门主管</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">在职人数</th>
                <th className="px-6 py-4 text-right text-[10px] font-bold text-slate-400 uppercase tracking-widest">管理</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {renderRows(departmentTree)}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-md rounded-[2rem] shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingDept ? '编辑部门资料' : '建立新部门'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-500"><X size={20}/></button>
            </div>
            <form onSubmit={handleAddOrEdit} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">部门名称</label>
                <input 
                  name="name"
                  defaultValue={editingDept?.name || ''}
                  required
                  placeholder="如：技术研发中心"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">上级部门</label>
                <select 
                  name="parentId"
                  defaultValue={editingDept?.parentId || ''}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="">设为顶级部门</option>
                  {departments
                    .filter(d => d.id !== editingDept?.id) // 防止互为上级
                    .map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">部门主管</label>
                <select 
                  name="managerName"
                  defaultValue={editingDept?.managerName || ''}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="">选择负责人</option>
                  {employees.map(e => (
                    <option key={e.id} value={e.name}>{e.name} ({e.position})</option>
                  ))}
                </select>
              </div>
              <div className="pt-4 flex gap-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-3 bg-slate-100 rounded-xl font-bold text-slate-600">取消</button>
                <button type="submit" className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2">
                  <Save size={18}/> 保存更改
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DepartmentManager;
