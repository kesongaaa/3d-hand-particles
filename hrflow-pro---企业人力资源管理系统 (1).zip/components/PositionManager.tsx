
import React, { useState, useMemo } from 'react';
import { 
  Landmark, Plus, Trash2, Edit3, X, Save, Briefcase, 
  Search, ChevronLeft, ChevronRight, ListFilter 
} from 'lucide-react';
import { Position } from '../types';

interface Props {
  positions: Position[];
  setPositions: React.Dispatch<React.SetStateAction<Position[]>>;
}

const PositionManager: React.FC<Props> = ({ positions, setPositions }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPos, setEditingPos] = useState<Position | null>(null);
  
  // 搜索与分页状态
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [jumpPage, setJumpPage] = useState('');

  // 1. 搜索过滤逻辑
  const filteredPositions = useMemo(() => {
    return positions.filter(pos => 
      pos.name.toLowerCase().includes(searchTerm.toLowerCase().trim())
    );
  }, [positions, searchTerm]);

  // 2. 分页计算逻辑
  const totalPages = Math.ceil(filteredPositions.length / pageSize);
  const paginatedPositions = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredPositions.slice(start, start + pageSize);
  }, [filteredPositions, currentPage, pageSize]);

  const handlePageChange = (p: number) => {
    if (p >= 1 && p <= totalPages) {
      setCurrentPage(p);
    }
  };

  const handleJump = () => {
    const p = parseInt(jumpPage);
    if (!isNaN(p) && p >= 1 && p <= totalPages) {
      setCurrentPage(p);
      setJumpPage('');
    }
  };

  const handleAddOrEdit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const name = (form.elements.namedItem('name') as HTMLInputElement).value;

    if (editingPos) {
      setPositions(prev => prev.map(p => p.id === editingPos.id ? { ...p, name } : p));
    } else {
      const newPos: Position = {
        id: `pos-${Date.now()}`,
        name
      };
      setPositions(prev => [...prev, newPos]);
    }
    setIsModalOpen(false);
    setEditingPos(null);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('确定要删除该职位名称吗？')) {
      setPositions(prev => prev.filter(p => p.id !== id));
    }
  };

  return (
    <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500">
      {/* 头部区域 */}
      <div className="flex justify-between items-center shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">职位管理</h2>
          <p className="text-slate-500">维护全司统一的职位职级体系，规范员工档案录入与架构对齐。</p>
        </div>
        <button 
          onClick={() => { setEditingPos(null); setIsModalOpen(true); }}
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
        >
          <Plus size={18} /> 新增职位
        </button>
      </div>

      {/* 搜索工具栏 */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="relative group w-full md:w-80">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">
            <Search size={18} />
          </div>
          <input 
            type="text"
            placeholder="搜索职位名称..."
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all shadow-sm"
          />
        </div>
      </div>

      {/* 列表容器：支持独立滚动 */}
      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm flex flex-col flex-1 overflow-hidden">
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead className="sticky top-0 z-10 bg-white">
              <tr className="bg-slate-50/80 backdrop-blur-sm">
                <th className="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100">职位名称</th>
                <th className="px-8 py-4 text-right text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100">管理</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {paginatedPositions.length > 0 ? (
                paginatedPositions.map((pos) => (
                  <tr key={pos.id} className="hover:bg-indigo-50/20 transition-all group">
                    <td className="px-8 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-slate-50 rounded-lg flex items-center justify-center text-slate-400 group-hover:bg-white group-hover:text-indigo-600 transition-all shadow-sm shrink-0">
                          <Briefcase size={18} />
                        </div>
                        <span className="text-sm font-bold text-slate-700">{pos.name}</span>
                      </div>
                    </td>
                    <td className="px-8 py-4 text-right">
                      <div className="flex justify-end gap-1">
                        <button 
                          onClick={() => { setEditingPos(pos); setIsModalOpen(true); }}
                          className="p-2 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                          title="编辑职位"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          onClick={() => handleDelete(pos.id)}
                          className="p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                          title="删除职位"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={2} className="px-8 py-20 text-center text-slate-400">
                    <div className="flex flex-col items-center gap-2">
                      <Landmark size={40} className="opacity-20" />
                      <p className="text-sm">暂无职位数据</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* 分页控制栏 */}
        <div className="px-8 py-4 bg-white border-t border-slate-50 flex flex-col md:flex-row justify-between items-center gap-4 shrink-0">
          <div className="flex items-center gap-4">
            <span className="text-xs text-slate-400 font-medium">每页显示</span>
            <select 
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            >
              {[20, 50, 100].map(v => <option key={v} value={v}>{v} 条</option>)}
            </select>
            <span className="text-xs text-slate-400 font-medium whitespace-nowrap">共 {filteredPositions.length} 个职位</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <button 
                disabled={currentPage === 1}
                onClick={() => handlePageChange(currentPage - 1)}
                className="p-1.5 rounded-lg border border-slate-100 text-slate-400 hover:bg-slate-50 disabled:opacity-30 transition-all"
              >
                <ChevronLeft size={18} />
              </button>
              
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let p = i + 1;
                  if (totalPages > 5 && currentPage > 3) {
                    p = currentPage - 2 + i;
                    if (p + 2 > totalPages) p = totalPages - 4 + i;
                  }
                  if (p <= 0 || p > totalPages) return null;
                  return (
                    <button 
                      key={p} 
                      onClick={() => handlePageChange(p)} 
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${currentPage === p ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
                    >
                      {p}
                    </button>
                  );
                })}
              </div>

              <button 
                disabled={currentPage === totalPages || totalPages === 0}
                onClick={() => handlePageChange(currentPage + 1)}
                className="p-1.5 rounded-lg border border-slate-100 text-slate-400 hover:bg-slate-50 disabled:opacity-30 transition-all"
              >
                <ChevronRight size={18} />
              </button>
            </div>

            <div className="flex items-center gap-2 pl-4 border-l border-slate-100">
              <span className="text-xs text-slate-400 font-medium whitespace-nowrap">跳转至</span>
              <input 
                type="text"
                value={jumpPage}
                onChange={(e) => setJumpPage(e.target.value.replace(/\D/g, ''))}
                onKeyDown={(e) => e.key === 'Enter' && handleJump()}
                className="w-12 h-8 bg-slate-50 border border-slate-200 rounded-lg text-center text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <span className="text-xs text-slate-400 font-medium">页</span>
            </div>
          </div>
        </div>
      </div>

      {/* 新增/编辑模态框 */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-sm rounded-[2rem] shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-lg font-bold">{editingPos ? '编辑职位' : '新增职位'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-slate-500 transition-colors"><X size={18}/></button>
            </div>
            <form onSubmit={handleAddOrEdit} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">职位名称</label>
                <input 
                  name="name"
                  defaultValue={editingPos?.name || ''}
                  required
                  autoFocus
                  placeholder="如：资深前端专家"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
              <button type="submit" className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all active:scale-[0.98]">
                <Save size={18}/> 确认提交
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PositionManager;
