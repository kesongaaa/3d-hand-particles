
export enum UserRole {
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  EMPLOYEE = 'EMPLOYEE'
}

export type EmployeeType = '正式' | '试用期' | '实习' | '兼职' | '劳务' | '外包';
export type Gender = '男' | '女';
export type EmployeeStatus = '在职' | '离职';

export interface FieldSetting {
  key: string;
  label: string;
  required: boolean;
  order: number; // 排序权重
}

export interface Department {
  id: string;
  name: string;
  managerName: string; // 部门主管
  order: number;
  parentId?: string; // 上级部门ID
}

export interface Position {
  id: string;
  name: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department: string;
  position: string;
  status: EmployeeStatus;
}

export interface Employee extends User {
  // 基本信息
  employeeId: string; // 工号
  idCard: string;     // 身份证号
  gender: Gender;     // 性别
  ethnicity: string;  // 民族
  politicalStatus: string; // 政治面貌
  phone: string;
  address: string;

  // 职业信息
  type: EmployeeType; // 员工类型
  joinDate: string;   // 入职时间
  salary: number;
  probationDuration: number; // 试用期时长（月）
  permanentDate: string;    // 转正时间
  
  // 教育信息
  education: string;  // 学历
  degree: string;     // 学位
  graduationDate: string; // 毕业时间

  // 财务信息
  bankCard: string;   // 银行卡号

  // 合同信息
  contractType: string; // 合同类型
  contractStartDate: string; // 合同起始时间
  contractEndDate: string;   // 合同到期时间
  
  probationEndDate?: string; // 旧字段兼容
}

export interface ApprovalRequest {
  id: string;
  type: '请假' | '报销' | '加班' | '转正';
  applicantId: string;
  applicantName: string;
  date: string;
  status: '待审批' | '已通过' | '已驳回';
  content: string;
  history?: { user: string; action: string; time: string }[];
}

export interface JobPost {
  id: string;
  title: string;
  department: string;
  location: string;
  type: '全职' | '实习' | '兼职';
  status: '发布中' | '已关闭' | '草稿';
  applicants: number;
  description: string;
}
