
import React from 'react';
import { 
  LayoutDashboard, Users, UserCircle, Briefcase, 
  Clock, CreditCard, Award, GraduationCap, Settings, 
  FileText, Network, Landmark 
} from 'lucide-react';
import { UserRole, Employee, JobPost, ApprovalRequest, FieldSetting, Department, Position } from './types';

export const NAV_ITEMS = [
  { id: 'dashboard', label: '仪表盘', icon: <LayoutDashboard size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.EMPLOYEE] },
  { id: 'employees', label: '员工管理', icon: <Users size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER] },
  { id: 'departments', label: '部门管理', icon: <Network size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER] },
  { id: 'positions', label: '职位管理', icon: <Landmark size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER] },
  { id: 'recruitment', label: '招聘管理', icon: <Briefcase size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER] },
  { id: 'attendance', label: '考勤排班', icon: <Clock size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.EMPLOYEE] },
  { id: 'approvals', label: '审批中心', icon: <FileText size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.EMPLOYEE] },
  { id: 'performance', label: '绩效考核', icon: <Award size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.EMPLOYEE] },
  { id: 'payroll', label: '薪酬福利', icon: <CreditCard size={20} />, roles: [UserRole.ADMIN] },
  { id: 'training', label: '培训发展', icon: <GraduationCap size={20} />, roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.EMPLOYEE] },
  { id: 'profile', label: '个人信息', icon: <UserCircle size={20} />, roles: [UserRole.EMPLOYEE, UserRole.MANAGER, UserRole.ADMIN] },
  { id: 'settings', label: '系统设置', icon: <Settings size={20} />, roles: [UserRole.ADMIN] },
];

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: 'root', name: '京报移动传媒有限公司', managerName: '系统预设', order: 0 },
  { id: 'dept-1', name: '集团领导', managerName: '', order: 1, parentId: 'root' },
  { id: 'dept-2', name: '总经理办公会', managerName: '', order: 2, parentId: 'root' },
  { id: 'dept-3', name: '版权运营部', managerName: '', order: 3, parentId: 'root' },
  { id: 'dept-4', name: '品牌推广部', managerName: '', order: 4, parentId: 'root' },
  { id: 'dept-5', name: '创意产品部', managerName: '', order: 5, parentId: 'root' },
  { id: 'dept-6', name: '京报网运营部', managerName: '', order: 6, parentId: 'root' },
  { id: 'dept-7', name: '技术开发部', managerName: '', order: 7, parentId: 'root' },
  { id: 'dept-8', name: '京报智库秘书处', managerName: '', order: 8, parentId: 'root' },
  { id: 'dept-9', name: '市场营销部', managerName: '', order: 9, parentId: 'root' },
  { id: 'dept-10', name: '运维支持中心', managerName: '', order: 10, parentId: 'root' },
  { id: 'dept-11', name: '报刊运营部', managerName: '', order: 11, parentId: 'root' },
  { id: 'dept-12', name: '综合办公室', managerName: '', order: 12, parentId: 'root' },
  { id: 'dept-hr', name: '人力资源部', managerName: '', order: 13, parentId: 'root' },
  { id: 'dept-13', name: '人才支持中心', managerName: '', order: 0, parentId: 'dept-hr' },
  { id: 'dept-14', name: '财务管理部', managerName: '', order: 14, parentId: 'root' },
];

export const INITIAL_POSITIONS: Position[] = [
  { id: 'pos-1', name: '前端开发' },
  { id: 'pos-2', name: '后端开发' },
  { id: 'pos-3', name: '产品经理' },
  { id: 'pos-4', name: '运营专家' },
  { id: 'pos-5', name: 'HRBP' },
  { id: 'pos-6', name: '财务专员' },
  { id: 'pos-7', name: '测试工程师' },
];

export const DEFAULT_FIELD_SETTINGS: FieldSetting[] = [
  { key: 'name', label: '姓名', required: true, order: 0 },
  { key: 'phone', label: '手机号', required: true, order: 1 },
  { key: 'idCard', label: '身份证号', required: true, order: 2 },
  { key: 'ethnicity', label: '民族', required: false, order: 3 },
  { key: 'politicalStatus', label: '政治面貌', required: false, order: 4 },
  { key: 'education', label: '学历', required: false, order: 5 },
  { key: 'bankCard', label: '银行卡号', required: false, order: 6 },
  { key: 'permanentDate', label: '转正日期', required: true, order: 7 },
  { key: 'contractEndDate', label: '合同到期', required: false, order: 8 },
];

const generateMockEmployees = (): Employee[] => {
  const departments = ['技术开发部', '人力资源部', '市场营销部', '综合办公室'];
  const base: Employee[] = [
    { 
      id: 'e1', employeeId: 'HF-001', name: '张伟', email: 'zhangwei@company.com', role: UserRole.ADMIN, department: '人力资源部', position: 'HR总监', status: '在职', type: '正式', joinDate: '2022-01-10', probationDuration: 3, permanentDate: '2022-04-10', salary: 35000, avatar: 'https://i.pravatar.cc/150?u=e1', phone: '13800138001', address: '北京市朝阳区', idCard: '11010119880101001X', gender: '男', ethnicity: '汉族', politicalStatus: '党员', education: '本科', degree: '学士', graduationDate: '2010-07-01', bankCard: '6222021001001234567', contractType: '劳动合同', contractStartDate: '2022-01-10', contractEndDate: '2025-01-09'
    }
  ];
  return base;
};

export const INITIAL_EMPLOYEES: Employee[] = generateMockEmployees();

export const INITIAL_JOBS: JobPost[] = [
  { id: 'j1', title: '高级架构师', department: '技术开发部', location: '杭州', type: '全职', status: '发布中', applicants: 24, description: '负责公司核心系统架构设计...' },
];

export const INITIAL_APPROVALS: ApprovalRequest[] = [
  { id: 'a1', type: '请假', applicantId: 'e3', applicantName: '王芳', date: '2024-05-21', status: '待审批', content: '申请年假 3 天。' },
];

export const MOCK_ATTENDANCE = [
  { id: '1', date: '2024-05-21', checkIn: '09:00', checkOut: '18:05', status: '正常' },
];

export const MOCK_COURSES = [
  { id: 'c1', title: 'HRBP 进阶课程', category: '专业技能', instructor: '张总', progress: 45 },
];

export const MOCK_USER = INITIAL_EMPLOYEES[0];
