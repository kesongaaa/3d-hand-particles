
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import EmployeeList from './components/EmployeeList';
import Recruitment from './components/Recruitment';
import Attendance from './components/Attendance';
import Payroll from './components/Payroll';
import Performance from './components/Performance';
import Training from './components/Training';
import Approvals from './components/Approvals';
import Profile from './components/Profile';
import Settings from './components/Settings';
import DepartmentManager from './components/DepartmentManager';
import PositionManager from './components/PositionManager';
import { UserRole, Employee, JobPost, ApprovalRequest, FieldSetting, Department, Position } from './types';
import { INITIAL_EMPLOYEES, INITIAL_JOBS, INITIAL_APPROVALS, DEFAULT_FIELD_SETTINGS, INITIAL_DEPARTMENTS, INITIAL_POSITIONS } from './constants';
import { Bell, Search, Settings as SettingsIcon, ChevronDown, LogOut, ShieldCheck } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userRole, setUserRole] = useState<UserRole>(UserRole.ADMIN);
  
  // 核心业务状态管理
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('hrms_employees');
    return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
  });
  
  const [jobs, setJobs] = useState<JobPost[]>(() => {
    const saved = localStorage.getItem('hrms_jobs');
    return saved ? JSON.parse(saved) : INITIAL_JOBS;
  });
  
  const [approvals, setApprovals] = useState<ApprovalRequest[]>(() => {
    const saved = localStorage.getItem('hrms_approvals');
    return saved ? JSON.parse(saved) : INITIAL_APPROVALS;
  });
  
  const [fieldSettings, setFieldSettings] = useState<FieldSetting[]>(() => {
    const saved = localStorage.getItem('hrms_field_settings');
    return saved ? JSON.parse(saved) : DEFAULT_FIELD_SETTINGS;
  });

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem('hrms_departments');
    return saved ? JSON.parse(saved) : INITIAL_DEPARTMENTS;
  });

  const [positions, setPositions] = useState<Position[]>(() => {
    const saved = localStorage.getItem('hrms_positions');
    return saved ? JSON.parse(saved) : INITIAL_POSITIONS;
  });

  // 持久化同步
  useEffect(() => {
    localStorage.setItem('hrms_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('hrms_jobs', JSON.stringify(jobs));
  }, [jobs]);

  useEffect(() => {
    localStorage.setItem('hrms_approvals', JSON.stringify(approvals));
  }, [approvals]);

  useEffect(() => {
    localStorage.setItem('hrms_field_settings', JSON.stringify(fieldSettings));
  }, [fieldSettings]);

  useEffect(() => {
    localStorage.setItem('hrms_departments', JSON.stringify(departments));
  }, [departments]);

  useEffect(() => {
    localStorage.setItem('hrms_positions', JSON.stringify(positions));
  }, [positions]);

  const toggleRole = () => {
    setUserRole(prev => (prev === UserRole.ADMIN ? UserRole.EMPLOYEE : UserRole.ADMIN));
  };

  const handleAddEmployee = (newEmp: Partial<Employee>) => {
    setEmployees(prev => [{ ...newEmp, id: Date.now().toString() } as Employee, ...prev]);
  };

  const handleBulkAddEmployees = (newEmployees: Employee[]) => {
    setEmployees(prev => [...newEmployees, ...prev]);
  };

  const handleUpdateEmployee = (updatedEmp: Partial<Employee>) => {
    setEmployees(prev => prev.map(e => e.id === updatedEmp.id ? { ...e, ...updatedEmp } as Employee : e));
  };

  const handleDeleteEmployee = (id: string) => {
    if (window.confirm('确定要永久删除该员工档案吗？此操作不可撤销。')) {
      setEmployees(prev => prev.filter(e => e.id !== id));
    }
  };

  const handleUpdateFieldSettings = (newSettings: FieldSetting[]) => {
    setFieldSettings(newSettings);
  };

  const handleAddJob = (newJob: JobPost) => {
    setJobs(prev => [newJob, ...prev]);
  };

  const handleSubmitApproval = (req: Partial<ApprovalRequest>) => {
    setApprovals(prev => [req as ApprovalRequest, ...prev]);
  };

  const handleProcessApproval = (id: string, status: '已通过' | '已驳回') => {
    setApprovals(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard employees={employees} jobs={jobs} approvals={approvals} />;
      case 'employees': return (
        <EmployeeList 
          employees={employees} 
          onAddEmployee={handleAddEmployee} 
          onUpdateEmployee={handleUpdateEmployee}
          onDeleteEmployee={handleDeleteEmployee}
          onBulkAddEmployees={handleBulkAddEmployees}
          fieldSettings={fieldSettings}
          onUpdateFieldSettings={handleUpdateFieldSettings}
          departments={departments}
          positions={positions}
        />
      );
      case 'departments': return <DepartmentManager employees={employees} departments={departments} setDepartments={setDepartments} />;
      case 'positions': return <PositionManager positions={positions} setPositions={setPositions} />;
      case 'recruitment': return <Recruitment jobs={jobs} onAddJob={handleAddJob} />;
      case 'attendance': return <Attendance />;
      case 'approvals': return <Approvals approvals={approvals} onAction={handleProcessApproval} onSubmit={handleSubmitApproval} />;
      case 'payroll': return <Payroll employees={employees} />;
      case 'performance': return <Performance />;
      case 'training': return <Training />;
      case 'profile': return <Profile />;
      case 'settings': return (
        <Settings 
          fieldSettings={fieldSettings} 
          onUpdateFieldSettings={handleUpdateFieldSettings} 
        />
      );
      default: return null;
    }
  };

  const roleNames = { [UserRole.ADMIN]: '管理员', [UserRole.MANAGER]: '经理', [UserRole.EMPLOYEE]: '员工' };

  return (
    <div className="flex h-screen w-full bg-[#f8fafc] overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} userRole={userRole} />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-50">
          <div className="flex items-center gap-8 flex-1">
             <div className="relative w-full max-w-md hidden md:block">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input 
                 type="text" 
                 placeholder="在企业中搜索内容..." 
                 className="w-full bg-slate-50 border-none rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 transition-all outline-none"
               />
             </div>
             <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100 animate-pulse">
                <ShieldCheck size={14} />
                <span className="text-[10px] font-black uppercase tracking-widest">组织架构实时同步</span>
             </div>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={toggleRole} className="hidden lg:flex items-center gap-2 bg-indigo-50 text-indigo-700 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-indigo-100 transition-colors">
              切换视角: {roleNames[userRole]}
            </button>
            <button className="relative p-2 text-slate-500 hover:bg-slate-50 rounded-lg transition-colors">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="group relative">
              <button className="flex items-center gap-3 p-1 pl-3 pr-2 bg-slate-50 border border-slate-200 rounded-xl hover:border-slate-300 transition-all">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-slate-900 leading-none">张伟</p>
                  <p className="text-[10px] text-slate-500 font-medium">{roleNames[userRole]}</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-indigo-100 overflow-hidden border border-indigo-200">
                  <img src="https://i.pravatar.cc/150?u=e1" alt="Profile" className="w-full h-full object-cover" />
                </div>
                <ChevronDown size={14} className="text-slate-400" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all py-2 z-[60]">
                <button onClick={() => setActiveTab('profile')} className="w-full px-4 py-2 text-left text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">个人资料</button>
                <button onClick={() => setActiveTab('settings')} className="w-full px-4 py-2 text-left text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">账号设置</button>
                <div className="h-[1px] bg-slate-100 my-1"></div>
                <button className="w-full px-4 py-2 text-left text-sm text-rose-600 hover:bg-rose-50 flex items-center gap-2"><LogOut size={16} /> 退出登录</button>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8 scroll-smooth">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
